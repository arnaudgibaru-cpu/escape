import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Lock, c as Briefcase, d as ArrowDown, i as Pause, l as ArrowUp, n as RotateCcw, o as LockOpen, r as Play, s as Eye, u as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BXV5ApdO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GAME_DURATION_MS = 18e5;
var STAGES = [
	{
		id: "regard",
		label: "Regard",
		n: "01"
	},
	{
		id: "constantes",
		label: "Constantes",
		n: "02"
	},
	{
		id: "materiel",
		label: "Matériel",
		n: "03"
	},
	{
		id: "sbar",
		label: "Message",
		n: "04"
	},
	{
		id: "tca",
		label: "TCA",
		n: "05"
	}
];
var CLUES = [
	{
		id: "plaie",
		title: "La plaie",
		caption: "Pied gauche, berges",
		body: "Rougeur extensive, exsudat jaunâtre, berges macérées. L’aspect a changé depuis la dernière visite. Ce n’est plus un simple pansement de confort.",
		clinical: true,
		image: "/game/wound.jpg"
	},
	{
		id: "teint",
		title: "Le teint",
		caption: "Visage, muqueuses",
		body: "Joues congestives, lèvres sèches, regard vitreux. Mme Lambert est fébrile, pas seulement « fatiguée par l’hiver ».",
		clinical: true,
		image: "/game/face.jpg"
	},
	{
		id: "pilulier",
		title: "Le pilulier",
		caption: "Semainier du vendredi",
		body: "Les alvéoles du vendredi soir sont encore pleines. Doses non prises — y compris, peut-être, un antidiabétique ou un antibiotique déjà prescrit.",
		clinical: true,
		image: "/game/pillbox.jpg"
	},
	{
		id: "chaussons",
		title: "Les chaussons",
		caption: "Chaussage intérieur",
		body: "Chaussons fermés, trop étroits, marque de frottement. Microtraumatisme et macération : le terreau d’une plaie du pied chez une personne âgée.",
		clinical: true,
		image: "/game/slippers.jpg"
	},
	{
		id: "piece",
		title: "La pièce",
		caption: "Thermomètre mural",
		body: "Radiateur froid. Le thermomètre mural affiche 16 °C. Pièce trop froide : vasoconstriction, inconfort, mauvaise perfusion d’un pied déjà fragile.",
		clinical: true,
		image: "/game/thermometer.jpg"
	},
	{
		id: "cadre",
		title: "Le cadre",
		caption: "Buffet de l’entrée",
		body: "Une photo de famille un peu poussiéreuse. Elle raconte l’isolement, pas l’urgence de ce soir. À noter pour plus tard — ce n’est pas un indice clinique.",
		clinical: false
	},
	{
		id: "the",
		title: "La tasse",
		caption: "Table basse",
		body: "Thé froid, à peine entamé. Hydratation incertaine, mais ce n’est pas ce qui fera basculer la décision ce soir.",
		clinical: false
	},
	{
		id: "tricot",
		title: "Le tricot",
		caption: "Accoudoir",
		body: "Une pelote et des aiguilles. Signe qu’elle tenait encore debout il y a peu. Pas un élément de conduite de soins immédiat.",
		clinical: false
	},
	{
		id: "telecommande",
		title: "La télécommande",
		caption: "Accoudoir du fauteuil",
		body: "Télévision allumée à bas volume. Elle n’est pas dans le coma. Rien à transmettre au spécialiste.",
		clinical: false
	}
];
var TRUE_CLUE_COUNT = CLUES.filter((c) => c.clinical).length;
var FICHES = [
	{
		id: "ta",
		slot: "ta",
		label: "Tension artérielle",
		value: "98 / 58 mmHg",
		detail: "Assise, bras droit"
	},
	{
		id: "spo2",
		slot: "spo2",
		label: "Saturation",
		value: "92 % AA",
		detail: "Oxymètre, 30 secondes"
	},
	{
		id: "glycemie",
		slot: "glycemie",
		label: "Glycémie capillaire",
		value: "2,48 g/L",
		detail: "Au pulpe, non à jeun"
	},
	{
		id: "fc",
		slot: "fc",
		label: "Fréquence cardiaque",
		value: "104 / min",
		detail: "Pouls radial, régulier"
	},
	{
		id: "temp",
		slot: "temp",
		label: "Température",
		value: "38,7 °C",
		detail: "Thermomètre tympanique — retrouvé dans la sacoche",
		inBag: true
	}
];
var VITAL_SLOTS = [
	{
		id: "ta",
		title: "Tension"
	},
	{
		id: "spo2",
		title: "SpO₂"
	},
	{
		id: "glycemie",
		title: "Glycémie"
	},
	{
		id: "fc",
		title: "Fréquence"
	},
	{
		id: "temp",
		title: "Température"
	}
];
var KIT_STEPS = [
	{
		id: "consent",
		title: "Identité et consentement",
		hint: "Vérifier Mme Lambert, expliquer la TCA, recueillir l’accord."
	},
	{
		id: "install",
		title: "Installer la patiente",
		hint: "Fauteuil, pied dégagé, bon éclairage, intimité préservée."
	},
	{
		id: "boot",
		title: "Allumer la tablette",
		hint: "Ouvrir la session TCA, vérifier le réseau."
	},
	{
		id: "audio",
		title: "Tester audio et cadrage",
		hint: "Visage dans le champ, volume, micro, contre-jour."
	},
	{
		id: "prep",
		title: "Préparer le champ d’examen",
		hint: "Gants, compresses, règle, champ propre autour de la plaie."
	},
	{
		id: "camera",
		title: "Brancher la caméra d’examen",
		hint: "Pas la webcam d’ambiance : le spécialiste doit voir les berges."
	}
];
var DEVICES = [
	{
		id: "exam",
		title: "Caméra d’examen",
		detail: "Optique rapprochée, câble USB. Seule façon de montrer les berges.",
		correct: true,
		image: "/game/exam-camera.jpg"
	},
	{
		id: "webcam",
		title: "Webcam d’ambiance",
		detail: "Cadrage du salon. Le pied reste un détail flou.",
		correct: false,
		image: "/game/kit.jpg"
	},
	{
		id: "stetho",
		title: "Stéthoscope connecté",
		detail: "Utile pour un souffle. Inutile pour une plaie du pied.",
		correct: false
	},
	{
		id: "gluco",
		title: "Glucomètre Bluetooth",
		detail: "La glycémie est déjà prise. Ce n’est pas le goulot d’étranglement.",
		correct: false
	}
];
var SBAR_KEYS = [
	{
		id: "identite",
		label: "Identité (Lambert, 84 ans)",
		test: (n) => /lambert/.test(n) || /\b84\b/.test(n)
	},
	{
		id: "isolement",
		label: "Isolement",
		test: (n) => /isol|seule|seul|entourage|famille abs/.test(n)
	},
	{
		id: "plaie",
		label: "Plaie du pied",
		test: (n) => /plaie|pied|ulcer|berges|exsud/.test(n)
	},
	{
		id: "fievre",
		label: "Fièvre",
		test: (n) => /fiev|febr|38/.test(n)
	},
	{
		id: "mt",
		label: "Médecin injoignable",
		test: (n) => /medecin|traitant|\bmt\b|injoign|joign/.test(n)
	},
	{
		id: "constantes",
		label: "Constantes chiffrées",
		test: (n) => /tension|98|spo2|saturation|92|glycem|2[.,]48|38[.,]7|104/.test(n)
	},
	{
		id: "contexte",
		label: "Vendredi, fin de tournée",
		test: (n) => /vendredi|17h|tournee|week.?end|derniere visite/.test(n)
	},
	{
		id: "demande",
		label: "Demande claire (avis / domicile)",
		test: (n) => /avis|tca|teleconsult|antibi|domicile|urgence|maintien|pansement/.test(n)
	}
];
var TCA_ACTIONS = [
	{
		id: "situation",
		label: "Présenter la situation",
		nurseLine: "Mme Lambert, 84 ans, isolée. Dernière visite de la tournée. Plaie du pied modifiée, fébrile, médecin traitant injoignable. On cherche à éviter les urgences.",
		doctorLine: () => "J’entends le contexte. Je n’ai encore rien vu. Montrez-moi ce qui justifie de rester à domicile.",
		feed: "face",
		points: () => 1
	},
	{
		id: "wound",
		label: "Cadrer la plaie",
		nurseLine: "Je vous montre le pied gauche, berges et pourtour.",
		doctorLine: ({ examCamera }) => examCamera ? "Là je vois. Rougeur extensive, exsudat, pas de nécrose franche, pas de crépitation. Merci d’avoir branché la caméra d’examen — sans elle je n’aurais pas tranché." : "C’est trop loin. Je vois un pansement, pas les berges. Si vous n’avez qu’une webcam d’ambiance, décrivez — mais je ne pourrai pas m’engager sur un maintien à domicile.",
		feed: "wound",
		points: (exam) => exam ? 3 : 1
	},
	{
		id: "vitals",
		label: "Lire les constantes",
		nurseLine: "Température 38,7 °C, TA 98/58, pouls 104, SpO₂ 92 % air ambiant, glycémie 2,48 g/L.",
		doctorLine: () => "Fièvre, tachycardie, saturation limite, glycémie haute. Ça tient un traitement oral si l’examen local est propre et si vous pouvez repasser ce week-end.",
		feed: "vitals",
		points: () => 2
	},
	{
		id: "home",
		label: "Décrire le domicile",
		nurseLine: "Elle vit seule. Pièce à 16 °C, radiateur éteint. Pas d’aidant ce soir. Je peux revenir demain.",
		doctorLine: () => "L’isolement et le froid comptent autant que la plaie. Si vous n’êtes pas en mesure d’assurer une surveillance, je n’ai plus d’argument pour le domicile.",
		feed: "room",
		points: () => 1
	},
	{
		id: "shoes",
		label: "Montrer le chaussage",
		nurseLine: "Chaussons fermés, trop étroits, marque de frottement. Elle marche encore un peu chez elle.",
		doctorLine: () => "Facteur causal. Consigne claire : pied libre, pas de chausson fermé, décharge, contrôle de la glycémie.",
		feed: "slippers",
		points: () => 1
	},
	{
		id: "pills",
		label: "Signaler le pilulier",
		nurseLine: "Les doses du vendredi soir sont encore dans le semainier. Observance douteuse.",
		doctorLine: () => "Inutile de prescrire si rien n’est pris. Faites-lui prendre la première dose sous vos yeux, et prévoyez le passage de demain.",
		feed: "pills",
		points: () => 1
	}
];
var DEBRIEF_POINTS = [
	{
		title: "Le spécialiste ne voit que ce que vous lui montrez",
		body: "Sans cadrage de plaie, sans constantes, sans contexte, l’avis se résume à « allez aux urgences ». La TCA n’est pas une magie à distance : c’est un examen clinique porté par l’IDEL."
	},
	{
		title: "Cinq regards valent un dossier",
		body: "Plaie, teint, pilulier, chaussons, température de la pièce. Ce sont des données, pas du décor. Elles tiennent dans une transmission de soixante secondes."
	},
	{
		title: "Le bon câble change la décision",
		body: "La webcam d’ambiance rassure le médecin sur la pièce. La caméra d’examen lui permet de traiter. Brancher le bon dispositif n’est pas un détail technique."
	},
	{
		title: "SBAR n’est pas de la paperasse",
		body: "Situation, contexte, constantes, demande. Un message flou produit une décision floue. Un message complet permet le maintien à domicile."
	},
	{
		title: "Pas de gagnant sans examen",
		body: "Le jeu n’a pas de vainqueur individuel. L’équipe gagne si l’examen est fait. C’est exactement le contrat d’une TCA réelle."
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function normalizeFr(value) {
	return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/['’]/g, " ");
}
function scoreSbar(text) {
	const n = normalizeFr(text);
	const hits = SBAR_KEYS.filter((k) => k.test(n)).map((k) => k.id);
	return {
		hits,
		missing: SBAR_KEYS.filter((k) => !hits.includes(k.id)),
		score: hits.length,
		passed: hits.length >= 6
	};
}
var initialRegard = {
	inspected: [],
	marks: {},
	lockValue: 0,
	tries: 0,
	unlocked: false
};
var initialConstantes = {
	placed: {},
	bagOpen: false,
	foundTemp: false,
	selectedFiche: null,
	unlocked: false
};
function shuffleIds(seed) {
	const ids = KIT_STEPS.map((s) => s.id);
	let s = Math.abs(seed) + 1;
	for (let i = ids.length - 1; i > 0; i--) {
		s = s * 16807 % 2147483647;
		const j = s % (i + 1);
		const a = ids[i];
		const b = ids[j];
		if (a && b) {
			ids[i] = b;
			ids[j] = a;
		}
	}
	if (ids.join() === KIT_STEPS.map((step) => step.id).join()) {
		const last = ids.pop();
		if (last) ids.unshift(last);
	}
	return ids;
}
var initialMateriel = {
	order: shuffleIds(17),
	plugged: null,
	orderOk: false,
	unlocked: false
};
var initialSbar = {
	situation: "",
	background: "",
	assessment: "",
	recommendation: "",
	running: false,
	endsAt: null,
	tries: 0,
	lastScore: 0,
	unlocked: false
};
var initialTca = {
	done: [],
	chat: [{
		who: "doctor",
		text: "Docteur Morel, infectiologie. Je n’ai pour l’instant que ce que votre caméra me montre. Allez-y — je ne peux rien sans vous."
	}],
	decided: false,
	score: 0,
	domicile: null
};
function checkConstantes(placed) {
	return FICHES.every((f) => placed[f.slot] === f.id);
}
function checkOrder(order) {
	return order.join() === KIT_STEPS.map((s) => s.id).join();
}
var useGame = create()(persist((set, get) => ({
	hydrated: false,
	stage: "intro",
	teamName: "",
	startedAt: null,
	pauseStartedAt: null,
	pausedMs: 0,
	regard: initialRegard,
	constantes: initialConstantes,
	materiel: initialMateriel,
	sbar: initialSbar,
	tca: initialTca,
	setHydrated: () => set({ hydrated: true }),
	setTeamName: (teamName) => set({ teamName }),
	start: () => {
		const now = Date.now();
		set({
			stage: "regard",
			startedAt: now,
			pauseStartedAt: null,
			pausedMs: 0,
			regard: { ...initialRegard },
			constantes: {
				...initialConstantes,
				placed: {}
			},
			materiel: {
				...initialMateriel,
				order: shuffleIds(now),
				plugged: null
			},
			sbar: { ...initialSbar },
			tca: {
				...initialTca,
				done: [],
				chat: [...initialTca.chat]
			}
		});
	},
	togglePause: () => {
		const { pauseStartedAt, pausedMs } = get();
		if (pauseStartedAt) set({
			pauseStartedAt: null,
			pausedMs: pausedMs + (Date.now() - pauseStartedAt)
		});
		else set({ pauseStartedAt: Date.now() });
	},
	remainingMs: () => {
		const { startedAt, pauseStartedAt, pausedMs } = get();
		if (!startedAt) return GAME_DURATION_MS;
		const frozen = pauseStartedAt ? Date.now() - pauseStartedAt : 0;
		return Math.max(0, GAME_DURATION_MS - (Date.now() - startedAt - pausedMs - frozen));
	},
	go: (stage) => set({ stage }),
	inspectClue: (id) => set((s) => ({ regard: {
		...s.regard,
		inspected: s.regard.inspected.includes(id) ? s.regard.inspected : [...s.regard.inspected, id]
	} })),
	markClue: (id, mark) => set((s) => ({ regard: {
		...s.regard,
		marks: {
			...s.regard.marks,
			[id]: mark
		}
	} })),
	setLockValue: (n) => set((s) => ({ regard: {
		...s.regard,
		lockValue: n
	} })),
	tryLock: () => {
		const { regard } = get();
		const ok = regard.lockValue === CLUES.filter((c) => c.clinical).length;
		set({ regard: {
			...regard,
			tries: regard.tries + 1,
			unlocked: ok || regard.unlocked
		} });
		return ok ? "ok" : "fail";
	},
	selectFiche: (id) => set((s) => ({ constantes: {
		...s.constantes,
		selectedFiche: id
	} })),
	placeFiche: (slot) => {
		const { constantes } = get();
		if (!constantes.selectedFiche) {
			const current = constantes.placed[slot];
			if (!current) return;
			const placed = { ...constantes.placed };
			delete placed[slot];
			set({ constantes: {
				...constantes,
				placed,
				selectedFiche: current,
				unlocked: false
			} });
			return;
		}
		const placed = {
			...constantes.placed,
			[slot]: constantes.selectedFiche
		};
		set({ constantes: {
			...constantes,
			placed,
			selectedFiche: null,
			unlocked: checkConstantes(placed)
		} });
	},
	toggleBag: (open) => set((s) => ({ constantes: {
		...s.constantes,
		bagOpen: open ?? !s.constantes.bagOpen
	} })),
	takeTemp: () => set((s) => ({ constantes: {
		...s.constantes,
		foundTemp: true,
		selectedFiche: "temp",
		bagOpen: false
	} })),
	moveStep: (index, dir) => {
		const { materiel } = get();
		const next = [...materiel.order];
		const j = index + dir;
		if (j < 0 || j >= next.length) return;
		const a = next[index];
		const b = next[j];
		if (!a || !b) return;
		next[index] = b;
		next[j] = a;
		const orderOk = checkOrder(next);
		set({ materiel: {
			...materiel,
			order: next,
			orderOk,
			unlocked: orderOk && materiel.plugged === "exam"
		} });
	},
	plugDevice: (id) => {
		const { materiel } = get();
		const orderOk = checkOrder(materiel.order);
		const correct = DEVICES.find((d) => d.id === id)?.correct ?? false;
		set({ materiel: {
			...materiel,
			plugged: id,
			orderOk,
			unlocked: orderOk && correct
		} });
	},
	setSbarField: (field, value) => set((s) => ({ sbar: {
		...s.sbar,
		[field]: value
	} })),
	startSbarTimer: () => set((s) => ({ sbar: {
		...s.sbar,
		running: true,
		endsAt: Date.now() + 6e4
	} })),
	submitSbar: () => {
		const { sbar } = get();
		const result = scoreSbar([
			sbar.situation,
			sbar.background,
			sbar.assessment,
			sbar.recommendation
		].join("\n"));
		set({ sbar: {
			...sbar,
			running: false,
			endsAt: null,
			tries: sbar.tries + 1,
			lastScore: result.score,
			unlocked: result.passed || sbar.unlocked
		} });
		return {
			passed: result.passed,
			score: result.score
		};
	},
	doTcaAction: (id) => {
		const { tca, materiel } = get();
		if (tca.done.includes(id) || tca.decided) return;
		const action = TCA_ACTIONS.find((a) => a.id === id);
		if (!action) return;
		const examCamera = materiel.plugged === "exam";
		set({ tca: {
			...tca,
			done: [...tca.done, id],
			score: tca.score + action.points(examCamera),
			chat: [
				...tca.chat,
				{
					who: "nurse",
					text: action.nurseLine
				},
				{
					who: "doctor",
					text: action.doctorLine({
						examCamera,
						already: tca.done
					})
				}
			]
		} });
	},
	decideTca: () => {
		const { tca, materiel } = get();
		if (tca.decided) return;
		const examCamera = materiel.plugged === "exam";
		const domicile = tca.score >= 7 && examCamera && tca.done.includes("wound") && tca.done.includes("vitals");
		const text = domicile ? "Je m’engage : antibiothérapie orale, pansement hydrocellulaire, décharge du pied, première dose maintenant, vous repassez demain. Maintien à domicile. Sans l’examen que vous venez de faire, j’aurais envoyé Mme Lambert aux urgences." : "Je ne peux pas m’engager sur un maintien à domicile : l’examen est trop incomplet. Orientez vers les urgences. Le spécialiste ne peut rien sans ce que l’IDEL lui montre et lui dit.";
		set({ tca: {
			...tca,
			decided: true,
			domicile,
			chat: [
				...tca.chat,
				{
					who: "system",
					text: "Décision du médecin à distance"
				},
				{
					who: "doctor",
					text
				}
			]
		} });
	},
	reset: () => set({
		stage: "intro",
		teamName: "",
		startedAt: null,
		pauseStartedAt: null,
		pausedMs: 0,
		regard: { ...initialRegard },
		constantes: {
			...initialConstantes,
			placed: {}
		},
		materiel: {
			...initialMateriel,
			order: shuffleIds(Date.now()),
			plugged: null
		},
		sbar: { ...initialSbar },
		tca: {
			...initialTca,
			done: [],
			chat: [...initialTca.chat]
		}
	})
}), {
	name: "derniere-visite-v1",
	skipHydration: true,
	partialize: (s) => ({
		stage: s.stage,
		teamName: s.teamName,
		startedAt: s.startedAt,
		pauseStartedAt: s.pauseStartedAt,
		pausedMs: s.pausedMs,
		regard: s.regard,
		constantes: s.constantes,
		materiel: s.materiel,
		sbar: s.sbar,
		tca: s.tca
	})
}));
function format(ms) {
	const s = Math.ceil(ms / 1e3);
	const m = Math.floor(s / 60);
	const r = s % 60;
	return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}
function Hud() {
	const stage = useGame((s) => s.stage);
	const remainingMs = useGame((s) => s.remainingMs);
	const pauseStartedAt = useGame((s) => s.pauseStartedAt);
	const togglePause = useGame((s) => s.togglePause);
	const reset = useGame((s) => s.reset);
	const regard = useGame((s) => s.regard.unlocked);
	const constantes = useGame((s) => s.constantes.unlocked);
	const materiel = useGame((s) => s.materiel.unlocked);
	const sbar = useGame((s) => s.sbar.unlocked);
	const tca = useGame((s) => s.tca.decided);
	const [now, setNow] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let raf = 0;
		const loop = () => {
			setNow(Date.now());
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, []);
	const left = remainingMs();
	const late = left < 3e5;
	const done = {
		regard,
		constantes,
		materiel,
		sbar,
		tca
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-border bg-ink/92 backdrop-blur-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden font-display text-lg text-fg sm:block",
						children: "Dernière visite"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex min-w-0 flex-1 items-center gap-1 overflow-x-auto",
						children: STAGES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("rounded-full px-2.5 py-1 text-[11px] tracking-wide uppercase", stage === s.id ? "bg-paper text-ink-fg" : done[s.id] ? "text-teal" : "text-fg-muted"),
							children: [
								s.n,
								" ",
								s.label
							]
						}, s.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("font-display text-xl tabular-nums", late ? "text-rust" : "text-fg", left === 0 && "text-fg-muted"),
							children: format(left)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: togglePause,
							className: "flex size-11 items-center justify-center rounded-md text-fg-muted hover:text-fg",
							"aria-label": pauseStartedAt ? "Reprendre" : "Pause",
							children: pauseStartedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
						})]
					})
				]
			}),
			pauseStartedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-4 border-t border-border px-4 py-2 text-sm text-fg-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pause animateur — le chronomètre est figé." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-fg underline-offset-2 hover:underline",
					onClick: reset,
					children: "Nouvelle partie"
				})]
			}) : null,
			left === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-t border-border px-4 py-2 text-center text-sm text-warn",
				children: "Temps imparti dépassé. Continuez : le débrief compte plus que la montre."
			}) : null
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal min-h-11", {
	variants: {
		variant: {
			primary: "bg-paper text-ink-fg shadow-[var(--shadow-paper)] hover:bg-paper-2",
			teal: "bg-teal text-teal-fg hover:bg-teal-deep",
			ghost: "bg-transparent text-fg hover:bg-fg/8 shadow-[var(--shadow-ink)]",
			paper: "bg-ink-fg text-paper hover:bg-ink",
			outline: "bg-transparent text-ink-fg shadow-[0_0_0_1px_rgb(28_25_21_/_0.16)] hover:bg-ink-fg/5",
			danger: "bg-rust text-fg hover:opacity-90"
		},
		size: {
			sm: "h-10 px-3.5 text-sm rounded-[10px]",
			md: "h-11 px-4 text-[15px] rounded-md",
			lg: "h-12 px-5 text-base rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Intro() {
	const start = useGame((s) => s.start);
	const setTeamName = useGame((s) => s.setTeamName);
	const teamName = useGame((s) => s.teamName);
	const startedAt = useGame((s) => s.startedAt);
	const stage = useGame((s) => s.stage);
	const go = useGame((s) => s.go);
	const reset = useGame((s) => s.reset);
	const [brief, setBrief] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-dvh overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/game/intro-door.jpg",
				alt: "Entrée d’un immeuble, au crépuscule, une infirmière s’approche avec sa sacoche.",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-ink via-ink/78 to-ink/25" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex min-h-dvh max-w-3xl flex-col justify-end px-5 pb-10 pt-16 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise-in text-xs tracking-[0.22em] text-warn uppercase",
						children: "Escape game IDEL · Téléconsultation assistée"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "rise-in mt-3 font-display text-[2.6rem] leading-[1.05] text-fg sm:text-6xl",
						children: ["Dernière visite", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-[1.4rem] text-fg-muted sm:text-3xl",
							children: "avant le week-end"
						})]
					}),
					!brief ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rise-in mt-8 max-w-xl space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base leading-relaxed text-fg-muted sm:text-lg",
								children: "Vendredi 17 h 30. Dernière porte de la tournée. Mme Lambert, 84 ans, isolée. Sa plaie a changé. Elle est fébrile. Le médecin traitant ne répond plus."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base leading-relaxed text-fg",
								children: "Vous avez trente minutes pour éviter les urgences."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-3 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "lg",
									onClick: () => setBrief(true),
									children: ["Recevoir la transmission", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								}), startedAt && stage !== "intro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "lg",
									onClick: () => go(stage === "intro" ? "regard" : stage),
									children: "Reprendre"
								}) : null]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rise-in mt-6 rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)] sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-[0.18em] text-ink-muted uppercase",
								children: "Transmission de 17 h 28"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-2xl",
								children: "Chez Mme Lambert"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-4 space-y-2 text-[15px] leading-relaxed text-ink-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Cinq épreuves. Une seule issue : un avis à distance fiable." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Le spécialiste ne peut rien sans l’IDEL." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "30 minutes, équipes de 3–4, autour d’un écran — salon, webinaire ou salle." })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-5 block text-sm text-ink-muted",
								children: ["Nom de l’équipe", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: teamName,
									onChange: (e) => setTeamName(e.target.value),
									placeholder: "Équipe de garde",
									className: "mt-1.5 h-11 w-full rounded-md bg-paper-2 px-3 text-ink-fg outline-none ring-teal focus:ring-2"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "teal",
									size: "lg",
									onClick: start,
									children: ["Entrer chez Mme Lambert", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								}), startedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: reset,
									children: "Effacer la partie"
								}) : null]
							})
						]
					})
				]
			})
		]
	});
}
function Regard() {
	const inspectClue = useGame((s) => s.inspectClue);
	const markClue = useGame((s) => s.markClue);
	const inspected = useGame((s) => s.regard.inspected);
	const marks = useGame((s) => s.regard.marks);
	const lockValue = useGame((s) => s.regard.lockValue);
	const setLockValue = useGame((s) => s.setLockValue);
	const tryLock = useGame((s) => s.tryLock);
	const unlocked = useGame((s) => s.regard.unlocked);
	const tries = useGame((s) => s.regard.tries);
	const go = useGame((s) => s.go);
	const [open, setOpen] = (0, import_react.useState)(null);
	const [shake, setShake] = (0, import_react.useState)(false);
	const markedClinical = CLUES.filter((c) => marks[c.id] === "indice").length;
	function submitLock() {
		if (tryLock() === "fail") {
			setShake(true);
			window.setTimeout(() => setShake(false), 400);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[1.35fr_0.9fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-warn uppercase",
					children: "Épreuve 01 · Le regard clinique"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl text-fg sm:text-4xl",
					children: "Observez le domicile"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted",
					children: "Cinq indices cliniques sont dans cette pièce. Le reste est du décor. Inspectez, triez, puis ouvrez le cadenas : le code est le nombre d’indices justes."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative mt-5 overflow-hidden rounded-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/game/room.jpg",
						alt: "Salon de Mme Lambert au crépuscule, fauteuil près de la fenêtre.",
						className: "aspect-video w-full object-cover"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3",
					children: CLUES.map((clue) => {
						const seen = inspected.includes(clue.id);
						const mark = marks[clue.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								inspectClue(clue.id);
								setOpen(clue);
							},
							className: cn("flex min-h-20 w-full flex-col items-start rounded-lg bg-ink-soft p-3 text-left shadow-[var(--shadow-ink)] transition-transform duration-150 active:scale-[0.98]", mark === "indice" && "ring-1 ring-teal", mark === "ecarte" && "opacity-55"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] tracking-wide text-fg-muted uppercase",
									children: seen ? "Inspecté" : "À ouvrir"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 font-medium text-fg",
									children: clue.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-fg-muted",
									children: clue.caption
								})
							]
						}) }, clue.id);
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)] sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.18em] text-ink-muted uppercase",
						children: "Carnet de tournée"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl",
						children: "Cadenas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm leading-relaxed text-ink-muted",
						children: [
							"Vous avez marqué ",
							markedClinical,
							" élément",
							markedClinical > 1 ? "s" : "",
							" comme indice. Le code n’est pas ce que vous avez cliqué : c’est le nombre d’indices cliniquement justes."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("mt-5 flex items-center justify-center gap-3", shake && "shake"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex size-11 items-center justify-center rounded-md bg-paper-2 text-xl",
								onClick: () => setLockValue(Math.max(0, lockValue - 1)),
								"aria-label": "Diminuer",
								children: "−"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex size-20 flex-col items-center justify-center rounded-lg bg-ink text-fg",
								children: [unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "size-6 text-teal" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-6 text-warn" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-3xl tabular-nums",
									children: lockValue
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex size-11 items-center justify-center rounded-md bg-paper-2 text-xl",
								onClick: () => setLockValue(Math.min(9, lockValue + 1)),
								"aria-label": "Augmenter",
								children: "+"
							})
						]
					}),
					unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-teal-deep",
							children: "Cinq regards. Plaie, teint, pilulier, chaussons, pièce froide. Le salon s’ouvre."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "teal",
							className: "w-full",
							onClick: () => go("constantes"),
							children: ["Reconstituer le dossier", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "paper",
							className: "w-full",
							onClick: submitLock,
							children: "Tenter le code"
						}), tries >= 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-ink-muted",
							children: [
								"Indice : seuls les éléments qui changent la conduite de soins comptent. Il y en a ",
								TRUE_CLUE_COUNT,
								"."
							]
						}) : tries >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-ink-muted",
							children: "Moins que le nombre d’objets du salon. Plus que trois."
						}) : tries >= 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-rust",
							children: "Ce n’est pas le bon nombre."
						}) : null]
					})
				]
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/70 p-4 sm:items-center",
			role: "dialog",
			"aria-modal": "true",
			onClick: () => setOpen(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[88dvh] w-full max-w-lg overflow-auto rounded-xl bg-paper p-4 text-ink-fg shadow-[var(--shadow-paper)] sm:p-6",
				onClick: (e) => e.stopPropagation(),
				children: [
					open.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: open.image,
						alt: "",
						className: "mb-4 aspect-[4/3] w-full rounded-lg object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 flex aspect-[4/3] items-end rounded-lg bg-paper-2 p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: open.title
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-wide text-ink-muted uppercase",
						children: open.caption
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 font-display text-2xl",
						children: open.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[15px] leading-relaxed text-ink-muted",
						children: open.body
					}),
					open.id === "piece" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-3xl tabular-nums text-ink-fg",
						children: "16 °C"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "teal",
							onClick: () => {
								markClue(open.id, "indice");
								setOpen(null);
							},
							children: "Indice clinique"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								markClue(open.id, "ecarte");
								setOpen(null);
							},
							children: "Décor"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "mt-3 flex w-full items-center justify-center gap-2 py-2 text-sm text-ink-muted",
						onClick: () => setOpen(null),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }), "Fermer"]
					})
				]
			})
		}) : null]
	});
}
function Constantes() {
	const placed = useGame((s) => s.constantes.placed);
	const selected = useGame((s) => s.constantes.selectedFiche);
	const foundTemp = useGame((s) => s.constantes.foundTemp);
	const bagOpen = useGame((s) => s.constantes.bagOpen);
	const unlocked = useGame((s) => s.constantes.unlocked);
	const selectFiche = useGame((s) => s.selectFiche);
	const placeFiche = useGame((s) => s.placeFiche);
	const toggleBag = useGame((s) => s.toggleBag);
	const takeTemp = useGame((s) => s.takeTemp);
	const go = useGame((s) => s.go);
	const tableFiches = FICHES.filter((f) => !f.inBag || foundTemp);
	const missingSlot = VITAL_SLOTS.find((s) => !placed[s.id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] text-warn uppercase",
				children: "Épreuve 02 · Les constantes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl text-fg sm:text-4xl",
				children: "Reconstituez le dossier"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted",
				children: "Les fiches sont éparpillées. Posez chaque valeur dans la bonne case. Une donnée manque : elle est dans la sacoche."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)] sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.16em] text-ink-muted uppercase",
							children: "Dossier · Lambert Jeanne · 84 ans"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid gap-2 sm:grid-cols-2",
							children: VITAL_SLOTS.map((slot) => {
								const ficheId = placed[slot.id];
								const fiche = FICHES.find((f) => f.id === ficheId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => placeFiche(slot.id),
									className: cn("min-h-24 rounded-lg p-3 text-left transition-transform duration-150 active:scale-[0.98]", fiche ? "bg-teal-deep text-teal-fg" : "bg-paper-2 text-ink-muted", selected && !fiche && "ring-2 ring-teal"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] tracking-wide uppercase",
										children: slot.title
									}), fiche ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-display text-2xl tabular-nums",
										children: fiche.value
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs opacity-80",
										children: fiche.detail
									})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm",
										children: selected ? "Poser la fiche ici" : slot.id === "temp" ? "Valeur absente" : "Case vide"
									})]
								}, slot.id);
							})
						}),
						unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "teal",
							className: "mt-5 w-full",
							onClick: () => go("materiel"),
							children: ["Préparer le kit TCA", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-ink-muted",
							children: missingSlot ? `Il manque encore : ${missingSlot.title}.` : "Vérifiez que chaque valeur est dans la bonne case."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl text-fg",
						children: "Fiches sur la table"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-2 sm:grid-cols-2",
						children: tableFiches.map((fiche) => {
							const used = Object.values(placed).includes(fiche.id);
							const active = selected === fiche.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: used,
								onClick: () => selectFiche(active ? null : fiche.id),
								className: cn("w-full rounded-lg bg-ink-soft p-3 text-left shadow-[var(--shadow-ink)]", active && "ring-1 ring-warn", used && "opacity-35"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] tracking-wide text-fg-muted uppercase",
									children: fiche.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-2xl tabular-nums text-fg",
									children: fiche.value
								})]
							}) }, fiche.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleBag(true),
						className: "relative mt-4 block w-full overflow-hidden rounded-xl text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/game/bag.jpg",
							alt: "Sacoche de tournée ouverte, matériel d’examen visible.",
							className: "aspect-[4/3] w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "absolute inset-x-3 bottom-3 flex items-center gap-2 rounded-md bg-ink/80 px-3 py-2 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }), "Fouiller la sacoche"]
						})]
					})
				] })]
			}),
			bagOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/70 p-4 sm:items-center",
				role: "dialog",
				"aria-modal": "true",
				onClick: () => toggleBag(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-lg rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)]",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-wide text-ink-muted uppercase",
							children: "Sacoche IDEL"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-2xl",
							children: "Thermomètre tympanique"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-ink-muted",
							children: "Glissé dans la poche latérale, encore allumé. La température n’a pas été recopiée sur le dossier."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-5xl tabular-nums",
							children: "38,7 °C"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "teal",
							className: "mt-5 w-full",
							onClick: takeTemp,
							children: "Prendre la fiche température"
						})
					]
				})
			}) : null
		]
	});
}
function Materiel() {
	const order = useGame((s) => s.materiel.order);
	const orderOk = useGame((s) => s.materiel.orderOk);
	const plugged = useGame((s) => s.materiel.plugged);
	const unlocked = useGame((s) => s.materiel.unlocked);
	const moveStep = useGame((s) => s.moveStep);
	const plugDevice = useGame((s) => s.plugDevice);
	const go = useGame((s) => s.go);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] text-warn uppercase",
				children: "Épreuve 03 · Le matériel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl text-fg sm:text-4xl",
				children: "Monter le kit TCA"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted",
				children: "Remettez les étapes dans l’ordre, puis branchez le dispositif qui permettra au médecin de voir vraiment la plaie."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-2",
					children: order.map((id, index) => {
						const step = KIT_STEPS.find((s) => s.id === id);
						if (!step) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("flex items-stretch gap-2 rounded-lg bg-ink-soft p-2 shadow-[var(--shadow-ink)]", orderOk && "ring-1 ring-teal/50"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex w-10 items-center justify-center font-display text-xl text-warn",
									children: String(index + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 py-2 pr-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium text-fg",
										children: step.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-fg-muted",
										children: step.hint
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "flex size-11 items-center justify-center text-fg-muted hover:text-fg",
										onClick: () => moveStep(index, -1),
										"aria-label": "Monter",
										disabled: orderOk,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "flex size-11 items-center justify-center text-fg-muted hover:text-fg",
										onClick: () => moveStep(index, 1),
										"aria-label": "Descendre",
										disabled: orderOk,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
									})]
								})
							]
						}, id);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/game/kit.jpg",
						alt: "Tablette de téléconsultation et caméra d’examen sur une table.",
						className: "aspect-[4/3] w-full rounded-xl object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-xl text-fg",
						children: "Brancher le bon dispositif"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-fg-muted",
						children: orderOk ? "L’ordre est bon. Quel câble pour la plaie ?" : "Validez d’abord l’ordre des étapes."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-2 sm:grid-cols-2",
						children: DEVICES.map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !orderOk || unlocked,
							onClick: () => plugDevice(device.id),
							className: cn("w-full overflow-hidden rounded-lg bg-ink-soft text-left shadow-[var(--shadow-ink)] disabled:opacity-40", plugged === device.id && device.correct && "ring-1 ring-teal", plugged === device.id && !device.correct && "ring-1 ring-rust"),
							children: [device.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: device.image,
								alt: "",
								className: "h-24 w-full object-cover"
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium text-fg",
									children: device.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xs text-fg-muted",
									children: device.detail
								})]
							})]
						}) }, device.id))
					}),
					plugged && !unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-rust",
						children: "Mauvais dispositif : le médecin verra le salon, pas les berges."
					}) : null,
					unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "primary",
						className: "mt-4 w-full",
						onClick: () => go("sbar"),
						children: ["Appeler le spécialiste", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					}) : null
				] })]
			})
		]
	});
}
var FIELDS = [
	{
		key: "situation",
		letter: "S",
		label: "Situation",
		placeholder: "Qui, quoi, maintenant…"
	},
	{
		key: "background",
		letter: "B",
		label: "Background",
		placeholder: "Isolement, tournée, médecin traitant…"
	},
	{
		key: "assessment",
		letter: "A",
		label: "Assessment",
		placeholder: "Plaie, teint, constantes chiffrées…"
	},
	{
		key: "recommendation",
		letter: "R",
		label: "Recommendation",
		placeholder: "Avis TCA, domicile ou urgences…"
	}
];
function Sbar() {
	const sbar = useGame((s) => s.sbar);
	const setSbarField = useGame((s) => s.setSbarField);
	const startSbarTimer = useGame((s) => s.startSbarTimer);
	const submitSbar = useGame((s) => s.submitSbar);
	const go = useGame((s) => s.go);
	const [left, setLeft] = (0, import_react.useState)(60);
	const [result, setResult] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!sbar.running || !sbar.endsAt) return;
		let raf = 0;
		const loop = () => {
			const s = Math.max(0, Math.ceil((sbar.endsAt - Date.now()) / 1e3));
			setLeft(s);
			if (s === 0) {
				submitSbar();
				setResult(scoreSbar([
					useGame.getState().sbar.situation,
					useGame.getState().sbar.background,
					useGame.getState().sbar.assessment,
					useGame.getState().sbar.recommendation
				].join("\n")));
				return;
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [
		sbar.running,
		sbar.endsAt,
		submitSbar
	]);
	function onSubmit() {
		submitSbar();
		setResult(scoreSbar([
			sbar.situation,
			sbar.background,
			sbar.assessment,
			sbar.recommendation
		].join("\n")));
	}
	const locked = !sbar.running && !sbar.unlocked && sbar.tries === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-6 sm:px-6 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] text-warn uppercase",
				children: "Épreuve 04 · Le message au spécialiste"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-fg sm:text-4xl",
					children: "Transmission SBAR"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("font-display text-3xl tabular-nums", sbar.running && left <= 10 ? "text-rust" : "text-fg"),
					children: sbar.running ? `${left}s` : "60s"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-[15px] leading-relaxed text-fg-muted",
				children: "Soixante secondes. Le coffre s’ouvre si les éléments clés sont là — pas s’il est joli."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-3",
				children: FIELDS.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block rounded-lg bg-paper p-3 text-ink-fg shadow-[var(--shadow-paper)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-8 items-center justify-center rounded-sm bg-ink text-sm text-fg",
							children: field.letter
						}), field.label]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: sbar[field.key],
						onChange: (e) => setSbarField(field.key, e.target.value),
						placeholder: field.placeholder,
						disabled: locked || sbar.unlocked && !sbar.running,
						rows: 2,
						className: "mt-2 w-full resize-none bg-transparent text-[15px] leading-relaxed text-ink-fg outline-none placeholder:text-ink-muted"
					})]
				}, field.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-wrap gap-3",
				children: [
					sbar.tries === 0 && !sbar.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: startSbarTimer,
						children: "Lancer les 60 secondes"
					}) : null,
					sbar.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "teal",
						onClick: onSubmit,
						children: "Envoyer la transmission"
					}) : null,
					!sbar.running && sbar.tries > 0 && !sbar.unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: startSbarTimer,
						children: "Réessayer"
					}) : null,
					sbar.unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "teal",
						onClick: () => go("tca"),
						children: ["Ouvrir la TCA", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					}) : null
				]
			}),
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-xl bg-ink-soft p-4 shadow-[var(--shadow-ink)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [sbar.unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "size-5 text-teal" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5 text-rust" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium text-fg",
						children: [
							result.score,
							" / ",
							SBAR_KEYS.length,
							" éléments clés — seuil",
							" ",
							6
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-1 sm:grid-cols-2",
					children: SBAR_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("text-sm", result.hits.includes(k.id) ? "text-teal" : "text-fg-muted"),
						children: [
							result.hits.includes(k.id) ? "Présent" : "Manquant",
							" · ",
							k.label
						]
					}, k.id))
				})]
			}) : null
		]
	});
}
var FEEDS = {
	room: {
		src: "/game/room.jpg",
		alt: "Ce que le médecin voit : le salon."
	},
	face: {
		src: "/game/face.jpg",
		alt: "Cadrage du visage de Mme Lambert."
	},
	wound: {
		src: "/game/wound.jpg",
		alt: "Cadrage rapproché de la plaie."
	},
	woundBlur: {
		src: "/game/wound.jpg",
		alt: "Plaie trop loin, image floue.",
		blur: true
	},
	vitals: {
		src: "/game/bag.jpg",
		alt: "Lecture des constantes."
	},
	slippers: {
		src: "/game/slippers.jpg",
		alt: "Chaussons de Mme Lambert."
	},
	pills: {
		src: "/game/pillbox.jpg",
		alt: "Pilulier de la semaine."
	}
};
function Tca() {
	const done = useGame((s) => s.tca.done);
	const chat = useGame((s) => s.tca.chat);
	const decided = useGame((s) => s.tca.decided);
	const domicile = useGame((s) => s.tca.domicile);
	const plugged = useGame((s) => s.materiel.plugged);
	const doTcaAction = useGame((s) => s.doTcaAction);
	const decideTca = useGame((s) => s.decideTca);
	const go = useGame((s) => s.go);
	const last = [...done].reverse()[0];
	const action = TCA_ACTIONS.find((a) => a.id === last);
	const exam = plugged === "exam";
	let feedKey = action?.feed ?? "room";
	if (feedKey === "wound" && !exam) feedKey = "woundBlur";
	const feed = FEEDS[feedKey] ?? FEEDS.room;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] text-warn uppercase",
				children: "Épreuve 05 · La TCA"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl text-fg sm:text-4xl",
				children: "Le médecin n’a que ce que vous lui montrez"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted",
				children: "Dr Morel est en visio. Il décide selon la qualité de l’examen — donc selon vous."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-[1.15fr_0.85fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "overflow-hidden rounded-xl bg-ink-soft shadow-[var(--shadow-ink)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: feed.src,
								alt: feed.alt,
								className: cn("aspect-video w-full object-cover", feed.blur && "scale-110 blur-[6px]")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-x-0 top-0 flex items-center justify-between px-4 py-3 text-xs tracking-wide text-fg uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Dr Morel · infectiologie" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-teal",
									children: "En ligne"
								})]
							}),
							feedKey === "vitals" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-x-4 bottom-4 rounded-md bg-ink/80 p-3 font-display text-lg tabular-nums text-fg",
								children: "38,7 °C · 98/58 · 104 · 92 % · 2,48 g/L"
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "max-h-[42vh] space-y-3 overflow-auto p-4",
						children: chat.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("max-w-[42ch] rounded-lg px-3 py-2 text-sm leading-relaxed", line.who === "doctor" && "bg-paper text-ink-fg", line.who === "nurse" && "ml-auto bg-teal text-teal-fg", line.who === "system" && "mx-auto bg-transparent text-center text-xs tracking-wide text-fg-muted uppercase"),
							children: line.text
						}, `${i}-${line.who}`))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl text-fg",
						children: "Vous faites l’examen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-2",
						children: TCA_ACTIONS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: done.includes(a.id) || decided,
							onClick: () => doTcaAction(a.id),
							className: cn("w-full rounded-lg bg-ink-soft px-4 py-3 text-left text-[15px] text-fg shadow-[var(--shadow-ink)] disabled:opacity-35", done.includes(a.id) && "ring-1 ring-teal/40"),
							children: a.label
						}) }, a.id))
					}),
					!decided ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						className: "mt-4 w-full",
						disabled: done.length < 3,
						onClick: decideTca,
						children: "Demander la décision"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-lg bg-paper p-4 text-ink-fg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-wide text-ink-muted uppercase",
								children: "Issue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-2xl",
								children: domicile ? "Maintien à domicile" : "Orientation aux urgences"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-ink-muted",
								children: domicile ? "Antibiothérapie orale, pansement spécifique, surveillance IDEL le week-end." : "L’examen n’était pas assez complet pour un avis à distance."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "teal",
								className: "mt-4 w-full",
								onClick: () => go("debrief"),
								children: ["Débrief", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						]
					})
				] })]
			})
		]
	});
}
function Debrief() {
	const teamName = useGame((s) => s.teamName);
	const domicile = useGame((s) => s.tca.domicile);
	const reset = useGame((s) => s.reset);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-dvh overflow-hidden bg-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/game/room.jpg",
				alt: "",
				className: "absolute inset-0 size-full object-cover opacity-25"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-ink/80" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-3xl px-5 py-12 sm:px-8 sm:py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.22em] text-warn uppercase",
						children: "Débrief · 5 minutes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl leading-tight text-fg sm:text-5xl",
						children: "Le spécialiste ne peut rien sans l’IDEL"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-lg leading-relaxed text-fg-muted",
						children: [teamName ? `${teamName} : ` : "", domicile ? "Mme Lambert reste chez elle parce que l’examen a été fait." : "Les urgences ont emporté la décision faute d’examen complet — c’est aussi une leçon utile."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("relative mx-auto mt-10 flex size-44 items-center justify-center rounded-full border-2 border-teal text-center"),
						style: { animation: "stamp-in 500ms cubic-bezier(0.22, 1, 0.36, 1) both" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rotate-[-6deg]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] tracking-[0.25em] text-teal uppercase",
								children: "Badge"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-display text-xl leading-tight text-fg",
								children: ["IDEL pionnier", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block",
									children: "TCA"
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-12 space-y-5",
						children: DEBRIEF_POINTS.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs tabular-nums text-ink-muted",
									children: String(i + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 font-display text-xl",
									children: p.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[15px] leading-relaxed text-ink-muted",
									children: p.body
								})
							]
						}, p.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-8 rounded-xl bg-teal-deep p-5 text-teal-fg sm:p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-[0.18em] uppercase opacity-80",
								children: "Premier pas sans risque"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-2xl",
								children: "Une session d’essai, ou un accompagnement à la première TCA réelle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed opacity-90",
								children: "Pas de patient en danger, pas de notation. Juste le geste — caméra d’examen, constantes, SBAR — une fois, avec quelqu’un au bout du fil."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "primary",
							onClick: reset,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Rejouer"]
						})
					})
				]
			})
		]
	});
}
function GameApp() {
	const stage = useGame((s) => s.stage);
	const setHydrated = useGame((s) => s.setHydrated);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		useGame.persist.rehydrate().then(() => {
			setHydrated();
			setReady(true);
		});
	}, [setHydrated]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-ink text-fg-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl",
			children: "Dernière visite"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-ink text-fg",
		children: [
			stage !== "intro" && stage !== "debrief" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {}) : null,
			stage === "intro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Intro, {}) : null,
			stage === "regard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Regard, {}) : null,
			stage === "constantes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Constantes, {}) : null,
			stage === "materiel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Materiel, {}) : null,
			stage === "sbar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sbar, {}) : null,
			stage === "tca" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tca, {}) : null,
			stage === "debrief" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Debrief, {}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
