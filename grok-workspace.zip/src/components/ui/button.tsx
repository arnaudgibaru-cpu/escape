import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal min-h-11",
  {
    variants: {
      variant: {
        primary:
          "bg-paper text-ink-fg shadow-[var(--shadow-paper)] hover:bg-paper-2",
        teal: "bg-teal text-teal-fg hover:bg-teal-deep",
        ghost:
          "bg-transparent text-fg hover:bg-fg/8 shadow-[var(--shadow-ink)]",
        paper:
          "bg-ink-fg text-paper hover:bg-ink",
        outline:
          "bg-transparent text-ink-fg shadow-[0_0_0_1px_rgb(28_25_21_/_0.16)] hover:bg-ink-fg/5",
        danger: "bg-rust text-fg hover:opacity-90",
      },
      size: {
        sm: "h-10 px-3.5 text-sm rounded-[10px]",
        md: "h-11 px-4 text-[15px] rounded-md",
        lg: "h-12 px-5 text-base rounded-lg",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}
