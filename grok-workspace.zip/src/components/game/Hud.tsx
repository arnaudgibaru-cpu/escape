import { useEffect, useState } from "react";
import { Pause, Play } from "lucide-react";
import { STAGES } from "@/lib/game/content";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

function format(ms: number) {
  const s = Math.ceil(ms / 1000);
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

export function Hud() {
  const stage = useGame((s) => s.stage);
  const remainingMs = useGame((s) => s.remainingMs);
  const pauseStartedAt = useGame((s) => s.pauseStartedAt);
  const togglePause = useGame((s) => s.togglePause);
  const reset = useGame((s) => s.reset);
  const regard = useGame((s) => s.regard.unlocked);
  const constantes = useGame((s) => s.constantes.unlocked);
  const materiel = useGame((s) => s.materiel.unlocked);
  const sbar = useGame((s) => s.sbar.unlocked);
  const tca = useGame((s) => s.tca.decided);
  const [now, setNow] = useState(0);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      setNow(Date.now());
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  void now;
  const left = remainingMs();
  const late = left < 5 * 60 * 1000;
  const done: Record<string, boolean> = {
    regard,
    constantes,
    materiel,
    sbar,
    tca,
  };

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-ink/92 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
        <p className="hidden font-display text-lg text-fg sm:block">
          Dernière visite
        </p>
        <nav className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto">
          {STAGES.map((s) => (
            <span
              key={s.id}
              className={cn(
                "rounded-full px-2.5 py-1 text-[11px] tracking-wide uppercase",
                stage === s.id
                  ? "bg-paper text-ink-fg"
                  : done[s.id]
                    ? "text-teal"
                    : "text-fg-muted",
              )}
            >
              {s.n} {s.label}
            </span>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "font-display text-xl tabular-nums",
              late ? "text-rust" : "text-fg",
              left === 0 && "text-fg-muted",
            )}
          >
            {format(left)}
          </span>
          <button
            type="button"
            onClick={togglePause}
            className="flex size-11 items-center justify-center rounded-md text-fg-muted hover:text-fg"
            aria-label={pauseStartedAt ? "Reprendre" : "Pause"}
          >
            {pauseStartedAt ? (
              <Play className="size-4" />
            ) : (
              <Pause className="size-4" />
            )}
          </button>
        </div>
      </div>
      {pauseStartedAt ? (
        <div className="flex items-center justify-center gap-4 border-t border-border px-4 py-2 text-sm text-fg-muted">
          <span>Pause animateur — le chronomètre est figé.</span>
          <button
            type="button"
            className="text-fg underline-offset-2 hover:underline"
            onClick={reset}
          >
            Nouvelle partie
          </button>
        </div>
      ) : null}
      {left === 0 ? (
        <p className="border-t border-border px-4 py-2 text-center text-sm text-warn">
          Temps imparti dépassé. Continuez : le débrief compte plus que la
          montre.
        </p>
      ) : null}
    </header>
  );
}
