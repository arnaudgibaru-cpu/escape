import { ArrowRight, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FICHES, VITAL_SLOTS } from "@/lib/game/content";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

export function Constantes() {
  const placed = useGame((s) => s.constantes.placed);
  const selected = useGame((s) => s.constantes.selectedFiche);
  const foundTemp = useGame((s) => s.constantes.foundTemp);
  const bagOpen = useGame((s) => s.constantes.bagOpen);
  const unlocked = useGame((s) => s.constantes.unlocked);
  const selectFiche = useGame((s) => s.selectFiche);
  const placeFiche = useGame((s) => s.placeFiche);
  const toggleBag = useGame((s) => s.toggleBag);
  const takeTemp = useGame((s) => s.takeTemp);
  const go = useGame((s) => s.go);

  const tableFiches = FICHES.filter((f) => !f.inBag || foundTemp);
  const missingSlot = VITAL_SLOTS.find((s) => !placed[s.id]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
      <p className="text-xs tracking-[0.2em] text-warn uppercase">
        Épreuve 02 · Les constantes
      </p>
      <h1 className="mt-1 font-display text-3xl text-fg sm:text-4xl">
        Reconstituez le dossier
      </h1>
      <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted">
        Les fiches sont éparpillées. Posez chaque valeur dans la bonne case.
        Une donnée manque : elle est dans la sacoche.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <section className="rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)] sm:p-6">
          <p className="text-xs tracking-[0.16em] text-ink-muted uppercase">
            Dossier · Lambert Jeanne · 84 ans
          </p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {VITAL_SLOTS.map((slot) => {
              const ficheId = placed[slot.id];
              const fiche = FICHES.find((f) => f.id === ficheId);
              return (
                <button
                  key={slot.id}
                  type="button"
                  onClick={() => placeFiche(slot.id)}
                  className={cn(
                    "min-h-24 rounded-lg p-3 text-left transition-transform duration-150 active:scale-[0.98]",
                    fiche ? "bg-teal-deep text-teal-fg" : "bg-paper-2 text-ink-muted",
                    selected && !fiche && "ring-2 ring-teal",
                  )}
                >
                  <span className="text-[11px] tracking-wide uppercase">
                    {slot.title}
                  </span>
                  {fiche ? (
                    <>
                      <p className="mt-1 font-display text-2xl tabular-nums">
                        {fiche.value}
                      </p>
                      <p className="text-xs opacity-80">{fiche.detail}</p>
                    </>
                  ) : (
                    <p className="mt-2 text-sm">
                      {selected
                        ? "Poser la fiche ici"
                        : slot.id === "temp"
                          ? "Valeur absente"
                          : "Case vide"}
                    </p>
                  )}
                </button>
              );
            })}
          </div>
          {unlocked ? (
            <Button
              variant="teal"
              className="mt-5 w-full"
              onClick={() => go("materiel")}
            >
              Préparer le kit TCA
              <ArrowRight className="size-4" />
            </Button>
          ) : (
            <p className="mt-4 text-sm text-ink-muted">
              {missingSlot
                ? `Il manque encore : ${missingSlot.title}.`
                : "Vérifiez que chaque valeur est dans la bonne case."}
            </p>
          )}
        </section>

        <section>
          <h2 className="font-display text-xl text-fg">Fiches sur la table</h2>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {tableFiches.map((fiche) => {
              const used = Object.values(placed).includes(fiche.id);
              const active = selected === fiche.id;
              return (
                <li key={fiche.id}>
                  <button
                    type="button"
                    disabled={used}
                    onClick={() => selectFiche(active ? null : fiche.id)}
                    className={cn(
                      "w-full rounded-lg bg-ink-soft p-3 text-left shadow-[var(--shadow-ink)]",
                      active && "ring-1 ring-warn",
                      used && "opacity-35",
                    )}
                  >
                    <p className="text-[11px] tracking-wide text-fg-muted uppercase">
                      {fiche.label}
                    </p>
                    <p className="mt-1 font-display text-2xl tabular-nums text-fg">
                      {fiche.value}
                    </p>
                  </button>
                </li>
              );
            })}
          </ul>

          <button
            type="button"
            onClick={() => toggleBag(true)}
            className="relative mt-4 block w-full overflow-hidden rounded-xl text-left"
          >
            <img
              src="/game/bag.jpg"
              alt="Sacoche de tournée ouverte, matériel d’examen visible."
              className="aspect-[4/3] w-full object-cover"
            />
            <span className="absolute inset-x-3 bottom-3 flex items-center gap-2 rounded-md bg-ink/80 px-3 py-2 text-sm text-fg">
              <Briefcase className="size-4" />
              Fouiller la sacoche
            </span>
          </button>
        </section>
      </div>

      {bagOpen ? (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-ink/70 p-4 sm:items-center"
          role="dialog"
          aria-modal="true"
          onClick={() => toggleBag(false)}
        >
          <div
            className="w-full max-w-lg rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)]"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-xs tracking-wide text-ink-muted uppercase">
              Sacoche IDEL
            </p>
            <h3 className="mt-1 font-display text-2xl">Thermomètre tympanique</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink-muted">
              Glissé dans la poche latérale, encore allumé. La température n’a
              pas été recopiée sur le dossier.
            </p>
            <p className="mt-4 font-display text-5xl tabular-nums">38,7 °C</p>
            <Button
              variant="teal"
              className="mt-5 w-full"
              onClick={takeTemp}
            >
              Prendre la fiche température
            </Button>
          </div>
        </div>
      ) : null}
    </main>
  );
}
