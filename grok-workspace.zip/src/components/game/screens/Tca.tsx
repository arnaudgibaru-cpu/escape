import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TCA_ACTIONS } from "@/lib/game/content";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

const FEEDS: Record<string, { src: string; alt: string; blur?: boolean }> = {
  room: {
    src: "/game/room.jpg",
    alt: "Ce que le médecin voit : le salon.",
  },
  face: {
    src: "/game/face.jpg",
    alt: "Cadrage du visage de Mme Lambert.",
  },
  wound: {
    src: "/game/wound.jpg",
    alt: "Cadrage rapproché de la plaie.",
  },
  woundBlur: {
    src: "/game/wound.jpg",
    alt: "Plaie trop loin, image floue.",
    blur: true,
  },
  vitals: {
    src: "/game/bag.jpg",
    alt: "Lecture des constantes.",
  },
  slippers: {
    src: "/game/slippers.jpg",
    alt: "Chaussons de Mme Lambert.",
  },
  pills: {
    src: "/game/pillbox.jpg",
    alt: "Pilulier de la semaine.",
  },
};

export function Tca() {
  const done = useGame((s) => s.tca.done);
  const chat = useGame((s) => s.tca.chat);
  const decided = useGame((s) => s.tca.decided);
  const domicile = useGame((s) => s.tca.domicile);
  const plugged = useGame((s) => s.materiel.plugged);
  const doTcaAction = useGame((s) => s.doTcaAction);
  const decideTca = useGame((s) => s.decideTca);
  const go = useGame((s) => s.go);

  const last = [...done].reverse()[0];
  const action = TCA_ACTIONS.find((a) => a.id === last);
  const exam = plugged === "exam";
  let feedKey = action?.feed ?? "room";
  if (feedKey === "wound" && !exam) feedKey = "woundBlur";
  const feed = FEEDS[feedKey] ?? FEEDS.room;

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
      <p className="text-xs tracking-[0.2em] text-warn uppercase">
        Épreuve 05 · La TCA
      </p>
      <h1 className="mt-1 font-display text-3xl text-fg sm:text-4xl">
        Le médecin n’a que ce que vous lui montrez
      </h1>
      <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted">
        Dr Morel est en visio. Il décide selon la qualité de l’examen — donc
        selon vous.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
        <section className="overflow-hidden rounded-xl bg-ink-soft shadow-[var(--shadow-ink)]">
          <div className="relative">
            <img
              src={feed.src}
              alt={feed.alt}
              className={cn(
                "aspect-video w-full object-cover",
                feed.blur && "scale-110 blur-[6px]",
              )}
            />
            <div className="absolute inset-x-0 top-0 flex items-center justify-between px-4 py-3 text-xs tracking-wide text-fg uppercase">
              <span>Dr Morel · infectiologie</span>
              <span className="text-teal">En ligne</span>
            </div>
            {feedKey === "vitals" ? (
              <div className="absolute inset-x-4 bottom-4 rounded-md bg-ink/80 p-3 font-display text-lg tabular-nums text-fg">
                38,7 °C · 98/58 · 104 · 92 % · 2,48 g/L
              </div>
            ) : null}
          </div>
          <div className="max-h-[42vh] space-y-3 overflow-auto p-4">
            {chat.map((line, i) => (
              <p
                key={`${i}-${line.who}`}
                className={cn(
                  "max-w-[42ch] rounded-lg px-3 py-2 text-sm leading-relaxed",
                  line.who === "doctor" && "bg-paper text-ink-fg",
                  line.who === "nurse" && "ml-auto bg-teal text-teal-fg",
                  line.who === "system" &&
                    "mx-auto bg-transparent text-center text-xs tracking-wide text-fg-muted uppercase",
                )}
              >
                {line.text}
              </p>
            ))}
          </div>
        </section>

        <aside>
          <h2 className="font-display text-xl text-fg">Vous faites l’examen</h2>
          <ul className="mt-3 grid gap-2">
            {TCA_ACTIONS.map((a) => (
              <li key={a.id}>
                <button
                  type="button"
                  disabled={done.includes(a.id) || decided}
                  onClick={() => doTcaAction(a.id)}
                  className={cn(
                    "w-full rounded-lg bg-ink-soft px-4 py-3 text-left text-[15px] text-fg shadow-[var(--shadow-ink)] disabled:opacity-35",
                    done.includes(a.id) && "ring-1 ring-teal/40",
                  )}
                >
                  {a.label}
                </button>
              </li>
            ))}
          </ul>
          {!decided ? (
            <Button
              variant="primary"
              className="mt-4 w-full"
              disabled={done.length < 3}
              onClick={decideTca}
            >
              Demander la décision
            </Button>
          ) : (
            <div className="mt-4 rounded-lg bg-paper p-4 text-ink-fg">
              <p className="text-xs tracking-wide text-ink-muted uppercase">
                Issue
              </p>
              <p className="mt-1 font-display text-2xl">
                {domicile
                  ? "Maintien à domicile"
                  : "Orientation aux urgences"}
              </p>
              <p className="mt-2 text-sm leading-relaxed text-ink-muted">
                {domicile
                  ? "Antibiothérapie orale, pansement spécifique, surveillance IDEL le week-end."
                  : "L’examen n’était pas assez complet pour un avis à distance."}
              </p>
              <Button
                variant="teal"
                className="mt-4 w-full"
                onClick={() => go("debrief")}
              >
                Débrief
                <ArrowRight className="size-4" />
              </Button>
            </div>
          )}
        </aside>
      </div>
    </main>
  );
}
