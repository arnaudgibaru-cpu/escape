import { useEffect, useState } from "react";
import { ArrowRight, Lock, Unlock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SBAR_KEYS, SBAR_THRESHOLD } from "@/lib/game/content";
import { scoreSbar } from "@/lib/game/sbar";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

const FIELDS = [
  {
    key: "situation" as const,
    letter: "S",
    label: "Situation",
    placeholder: "Qui, quoi, maintenant…",
  },
  {
    key: "background" as const,
    letter: "B",
    label: "Background",
    placeholder: "Isolement, tournée, médecin traitant…",
  },
  {
    key: "assessment" as const,
    letter: "A",
    label: "Assessment",
    placeholder: "Plaie, teint, constantes chiffrées…",
  },
  {
    key: "recommendation" as const,
    letter: "R",
    label: "Recommendation",
    placeholder: "Avis TCA, domicile ou urgences…",
  },
];

export function Sbar() {
  const sbar = useGame((s) => s.sbar);
  const setSbarField = useGame((s) => s.setSbarField);
  const startSbarTimer = useGame((s) => s.startSbarTimer);
  const submitSbar = useGame((s) => s.submitSbar);
  const go = useGame((s) => s.go);
  const [left, setLeft] = useState(60);
  const [result, setResult] = useState<ReturnType<typeof scoreSbar> | null>(
    null,
  );

  useEffect(() => {
    if (!sbar.running || !sbar.endsAt) return;
    let raf = 0;
    const loop = () => {
      const s = Math.max(0, Math.ceil((sbar.endsAt! - Date.now()) / 1000));
      setLeft(s);
      if (s === 0) {
        const r = submitSbar();
        setResult(
          scoreSbar(
            [
              useGame.getState().sbar.situation,
              useGame.getState().sbar.background,
              useGame.getState().sbar.assessment,
              useGame.getState().sbar.recommendation,
            ].join("\n"),
          ),
        );
        void r;
        return;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [sbar.running, sbar.endsAt, submitSbar]);

  function onSubmit() {
    submitSbar();
    setResult(
      scoreSbar(
        [
          sbar.situation,
          sbar.background,
          sbar.assessment,
          sbar.recommendation,
        ].join("\n"),
      ),
    );
  }

  const locked = !sbar.running && !sbar.unlocked && sbar.tries === 0;

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6 sm:py-8">
      <p className="text-xs tracking-[0.2em] text-warn uppercase">
        Épreuve 04 · Le message au spécialiste
      </p>
      <div className="mt-1 flex items-end justify-between gap-4">
        <h1 className="font-display text-3xl text-fg sm:text-4xl">
          Transmission SBAR
        </h1>
        <p
          className={cn(
            "font-display text-3xl tabular-nums",
            sbar.running && left <= 10 ? "text-rust" : "text-fg",
          )}
        >
          {sbar.running ? `${left}s` : "60s"}
        </p>
      </div>
      <p className="mt-3 text-[15px] leading-relaxed text-fg-muted">
        Soixante secondes. Le coffre s’ouvre si les éléments clés sont là —
        pas s’il est joli.
      </p>

      <div className="mt-6 space-y-3">
        {FIELDS.map((field) => (
          <label
            key={field.key}
            className="block rounded-lg bg-paper p-3 text-ink-fg shadow-[var(--shadow-paper)]"
          >
            <span className="flex items-center gap-2 text-sm">
              <span className="flex size-8 items-center justify-center rounded-sm bg-ink text-sm text-fg">
                {field.letter}
              </span>
              {field.label}
            </span>
            <textarea
              value={sbar[field.key]}
              onChange={(e) => setSbarField(field.key, e.target.value)}
              placeholder={field.placeholder}
              disabled={locked || (sbar.unlocked && !sbar.running)}
              rows={2}
              className="mt-2 w-full resize-none bg-transparent text-[15px] leading-relaxed text-ink-fg outline-none placeholder:text-ink-muted"
            />
          </label>
        ))}
      </div>

      <div className="mt-5 flex flex-wrap gap-3">
        {sbar.tries === 0 && !sbar.running ? (
          <Button variant="primary" onClick={startSbarTimer}>
            Lancer les 60 secondes
          </Button>
        ) : null}
        {sbar.running ? (
          <Button variant="teal" onClick={onSubmit}>
            Envoyer la transmission
          </Button>
        ) : null}
        {!sbar.running && sbar.tries > 0 && !sbar.unlocked ? (
          <Button variant="primary" onClick={startSbarTimer}>
            Réessayer
          </Button>
        ) : null}
        {sbar.unlocked ? (
          <Button variant="teal" onClick={() => go("tca")}>
            Ouvrir la TCA
            <ArrowRight className="size-4" />
          </Button>
        ) : null}
      </div>

      {result ? (
        <div className="mt-6 rounded-xl bg-ink-soft p-4 shadow-[var(--shadow-ink)]">
          <div className="flex items-center gap-2">
            {sbar.unlocked ? (
              <Unlock className="size-5 text-teal" />
            ) : (
              <Lock className="size-5 text-rust" />
            )}
            <p className="font-medium text-fg">
              {result.score} / {SBAR_KEYS.length} éléments clés — seuil{" "}
              {SBAR_THRESHOLD}
            </p>
          </div>
          <ul className="mt-3 grid gap-1 sm:grid-cols-2">
            {SBAR_KEYS.map((k) => (
              <li
                key={k.id}
                className={cn(
                  "text-sm",
                  result.hits.includes(k.id) ? "text-teal" : "text-fg-muted",
                )}
              >
                {result.hits.includes(k.id) ? "Présent" : "Manquant"} · {k.label}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </main>
  );
}
