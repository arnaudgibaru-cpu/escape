import { ArrowDown, ArrowRight, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DEVICES, KIT_STEPS } from "@/lib/game/content";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

export function Materiel() {
  const order = useGame((s) => s.materiel.order);
  const orderOk = useGame((s) => s.materiel.orderOk);
  const plugged = useGame((s) => s.materiel.plugged);
  const unlocked = useGame((s) => s.materiel.unlocked);
  const moveStep = useGame((s) => s.moveStep);
  const plugDevice = useGame((s) => s.plugDevice);
  const go = useGame((s) => s.go);

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
      <p className="text-xs tracking-[0.2em] text-warn uppercase">
        Épreuve 03 · Le matériel
      </p>
      <h1 className="mt-1 font-display text-3xl text-fg sm:text-4xl">
        Monter le kit TCA
      </h1>
      <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted">
        Remettez les étapes dans l’ordre, puis branchez le dispositif qui
        permettra au médecin de voir vraiment la plaie.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <ol className="space-y-2">
          {order.map((id, index) => {
            const step = KIT_STEPS.find((s) => s.id === id);
            if (!step) return null;
            return (
              <li
                key={id}
                className={cn(
                  "flex items-stretch gap-2 rounded-lg bg-ink-soft p-2 shadow-[var(--shadow-ink)]",
                  orderOk && "ring-1 ring-teal/50",
                )}
              >
                <span className="flex w-10 items-center justify-center font-display text-xl text-warn">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className="flex-1 py-2 pr-2">
                  <p className="font-medium text-fg">{step.title}</p>
                  <p className="text-sm text-fg-muted">{step.hint}</p>
                </div>
                <div className="flex flex-col">
                  <button
                    type="button"
                    className="flex size-11 items-center justify-center text-fg-muted hover:text-fg"
                    onClick={() => moveStep(index, -1)}
                    aria-label="Monter"
                    disabled={orderOk}
                  >
                    <ArrowUp className="size-4" />
                  </button>
                  <button
                    type="button"
                    className="flex size-11 items-center justify-center text-fg-muted hover:text-fg"
                    onClick={() => moveStep(index, 1)}
                    aria-label="Descendre"
                    disabled={orderOk}
                  >
                    <ArrowDown className="size-4" />
                  </button>
                </div>
              </li>
            );
          })}
        </ol>

        <section>
          <img
            src="/game/kit.jpg"
            alt="Tablette de téléconsultation et caméra d’examen sur une table."
            className="aspect-[4/3] w-full rounded-xl object-cover"
          />
          <h2 className="mt-4 font-display text-xl text-fg">
            Brancher le bon dispositif
          </h2>
          <p className="mt-1 text-sm text-fg-muted">
            {orderOk
              ? "L’ordre est bon. Quel câble pour la plaie ?"
              : "Validez d’abord l’ordre des étapes."}
          </p>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {DEVICES.map((device) => (
              <li key={device.id}>
                <button
                  type="button"
                  disabled={!orderOk || unlocked}
                  onClick={() => plugDevice(device.id)}
                  className={cn(
                    "w-full overflow-hidden rounded-lg bg-ink-soft text-left shadow-[var(--shadow-ink)] disabled:opacity-40",
                    plugged === device.id && device.correct && "ring-1 ring-teal",
                    plugged === device.id && !device.correct && "ring-1 ring-rust",
                  )}
                >
                  {device.image ? (
                    <img
                      src={device.image}
                      alt=""
                      className="h-24 w-full object-cover"
                    />
                  ) : null}
                  <span className="block p-3">
                    <span className="block font-medium text-fg">
                      {device.title}
                    </span>
                    <span className="mt-1 block text-xs text-fg-muted">
                      {device.detail}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
          {plugged && !unlocked ? (
            <p className="mt-3 text-sm text-rust">
              Mauvais dispositif : le médecin verra le salon, pas les berges.
            </p>
          ) : null}
          {unlocked ? (
            <Button
              variant="primary"
              className="mt-4 w-full"
              onClick={() => go("sbar")}
            >
              Appeler le spécialiste
              <ArrowRight className="size-4" />
            </Button>
          ) : null}
        </section>
      </div>
    </main>
  );
}
