import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useGame } from "@/lib/game/store";

export function Intro() {
  const start = useGame((s) => s.start);
  const setTeamName = useGame((s) => s.setTeamName);
  const teamName = useGame((s) => s.teamName);
  const [brief, setBrief] = useState(false);

  return (
    <main className="relative min-h-dvh overflow-hidden">
      <img
        src="/game/intro-door.jpg"
        alt="Entrée d’un immeuble, au crépuscule, une infirmière s’approche avec sa sacoche."
        className="absolute inset-0 size-full object-cover object-[center_30%]"
      />
      <div className="absolute inset-0 bg-linear-to-t from-ink from-35% via-ink/55 to-ink/10" />
      <div className="relative mx-auto flex min-h-dvh max-w-3xl flex-col justify-end px-5 pb-8 pt-10 sm:px-8">
        <p className="rise-in text-xs tracking-[0.22em] text-warn uppercase">
          Escape game IDEL · Téléconsultation assistée
        </p>
        <h1 className="rise-in mt-2 font-display text-[clamp(2.25rem,6vw,3.5rem)] leading-[1.08] text-fg">
          Dernière visite
          <span className="mt-1 block text-[clamp(1.15rem,3vw,1.75rem)] text-fg-muted">
            avant le week-end
          </span>
        </h1>

        {!brief ? (
          <div className="rise-in mt-5 max-w-xl space-y-4">
            <p className="text-[15px] leading-relaxed text-fg-muted sm:text-base">
              Vendredi 17 h 30. Dernière porte de la tournée. Mme Lambert, 84
              ans, isolée. Sa plaie a changé. Elle est fébrile. Le médecin
              traitant ne répond plus. Trente minutes pour éviter les urgences.
            </p>
            <Button size="lg" onClick={() => setBrief(true)}>
              Recevoir la transmission
              <ArrowRight className="size-4" />
            </Button>
          </div>
        ) : (
          <div className="rise-in mt-5 rounded-xl bg-paper p-4 text-ink-fg shadow-[var(--shadow-paper)] sm:p-6">
            <p className="text-xs tracking-[0.18em] text-ink-muted uppercase">
              Transmission de 17 h 28
            </p>
            <h2 className="mt-1 font-display text-2xl">Chez Mme Lambert</h2>
            <ul className="mt-3 space-y-1.5 text-sm leading-relaxed text-ink-muted sm:text-[15px]">
              <li>Cinq épreuves. Une seule issue : un avis à distance fiable.</li>
              <li>Le spécialiste ne peut rien sans l’IDEL.</li>
              <li>
                30 minutes, équipes de 3–4, autour d’un écran — salon, webinaire
                ou salle.
              </li>
            </ul>
            <label className="mt-4 block text-sm text-ink-muted">
              Nom de l’équipe
              <input
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                placeholder="Équipe de garde"
                className="mt-1.5 h-11 w-full rounded-md bg-paper-2 px-3 text-ink-fg outline-none ring-teal focus:ring-2"
              />
            </label>
            <div className="mt-4">
              <Button variant="teal" size="lg" onClick={start}>
                Entrer chez Mme Lambert
                <ArrowRight className="size-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
