import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DEBRIEF_POINTS } from "@/lib/game/content";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

export function Debrief() {
  const teamName = useGame((s) => s.teamName);
  const domicile = useGame((s) => s.tca.domicile);
  const reset = useGame((s) => s.reset);

  return (
    <main className="relative min-h-dvh overflow-hidden bg-ink">
      <img
        src="/game/room.jpg"
        alt=""
        className="absolute inset-0 size-full object-cover opacity-25"
      />
      <div className="absolute inset-0 bg-ink/80" />
      <div className="relative mx-auto max-w-3xl px-5 py-12 sm:px-8 sm:py-16">
        <p className="text-xs tracking-[0.22em] text-warn uppercase">
          Débrief · 5 minutes
        </p>
        <h1 className="mt-2 font-display text-4xl leading-tight text-fg sm:text-5xl">
          Le spécialiste ne peut rien sans l’IDEL
        </h1>
        <p className="mt-4 text-lg leading-relaxed text-fg-muted">
          {teamName ? `${teamName} : ` : ""}
          {domicile
            ? "Mme Lambert reste chez elle parce que l’examen a été fait."
            : "Les urgences ont emporté la décision faute d’examen complet — c’est aussi une leçon utile."}
        </p>

        <div
          className={cn(
            "relative mx-auto mt-10 flex size-44 items-center justify-center rounded-full border-2 border-teal text-center",
          )}
          style={{ animation: "stamp-in 500ms cubic-bezier(0.22, 1, 0.36, 1) both" }}
        >
          <div className="rotate-[-6deg]">
            <p className="text-[10px] tracking-[0.25em] text-teal uppercase">
              Badge
            </p>
            <p className="mt-1 font-display text-xl leading-tight text-fg">
              IDEL pionnier
              <span className="block">TCA</span>
            </p>
          </div>
        </div>

        <ol className="mt-12 space-y-5">
          {DEBRIEF_POINTS.map((p, i) => (
            <li key={p.title} className="rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)]">
              <p className="text-xs tabular-nums text-ink-muted">
                {String(i + 1).padStart(2, "0")}
              </p>
              <h2 className="mt-1 font-display text-xl">{p.title}</h2>
              <p className="mt-2 text-[15px] leading-relaxed text-ink-muted">
                {p.body}
              </p>
            </li>
          ))}
        </ol>

        <section className="mt-8 rounded-xl bg-teal-deep p-5 text-teal-fg sm:p-6">
          <p className="text-xs tracking-[0.18em] uppercase opacity-80">
            Premier pas sans risque
          </p>
          <h2 className="mt-2 font-display text-2xl">
            Une session d’essai, ou un accompagnement à la première TCA réelle
          </h2>
          <p className="mt-2 text-sm leading-relaxed opacity-90">
            Pas de patient en danger, pas de notation. Juste le geste — caméra
            d’examen, constantes, SBAR — une fois, avec quelqu’un au bout du
            fil.
          </p>
        </section>

        <div className="mt-8 flex flex-wrap gap-3">
          <Button variant="primary" onClick={reset}>
            <RotateCcw className="size-4" />
            Rejouer
          </Button>
        </div>
      </div>
    </main>
  );
}
