import { useState } from "react";
import { ArrowRight, Eye, Lock, Unlock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CLUES, TRUE_CLUE_COUNT, type Clue } from "@/lib/game/content";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

export function Regard() {
  const inspectClue = useGame((s) => s.inspectClue);
  const markClue = useGame((s) => s.markClue);
  const inspected = useGame((s) => s.regard.inspected);
  const marks = useGame((s) => s.regard.marks);
  const lockValue = useGame((s) => s.regard.lockValue);
  const setLockValue = useGame((s) => s.setLockValue);
  const tryLock = useGame((s) => s.tryLock);
  const unlocked = useGame((s) => s.regard.unlocked);
  const tries = useGame((s) => s.regard.tries);
  const go = useGame((s) => s.go);
  const [open, setOpen] = useState<Clue | null>(null);
  const [shake, setShake] = useState(false);

  const markedClinical = CLUES.filter((c) => marks[c.id] === "indice").length;

  function submitLock() {
    const result = tryLock();
    if (result === "fail") {
      setShake(true);
      window.setTimeout(() => setShake(false), 400);
    }
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
      <div className="grid gap-6 lg:grid-cols-[1.35fr_0.9fr]">
        <section>
          <p className="text-xs tracking-[0.2em] text-warn uppercase">
            Épreuve 01 · Le regard clinique
          </p>
          <h1 className="mt-1 font-display text-3xl text-fg sm:text-4xl">
            Observez le domicile
          </h1>
          <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-fg-muted">
            Cinq indices cliniques sont dans cette pièce. Le reste est du
            décor. Inspectez, triez, puis ouvrez le cadenas : le code est le
            nombre d’indices justes.
          </p>
          <div className="relative mt-5 overflow-hidden rounded-xl">
            <img
              src="/game/room.jpg"
              alt="Salon de Mme Lambert au crépuscule, fauteuil près de la fenêtre."
              className="aspect-video w-full object-cover"
            />
          </div>
          <ul className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {CLUES.map((clue) => {
              const seen = inspected.includes(clue.id);
              const mark = marks[clue.id];
              return (
                <li key={clue.id}>
                  <button
                    type="button"
                    onClick={() => {
                      inspectClue(clue.id);
                      setOpen(clue);
                    }}
                    className={cn(
                      "flex min-h-20 w-full flex-col items-start rounded-lg bg-ink-soft p-3 text-left shadow-[var(--shadow-ink)] transition-transform duration-150 active:scale-[0.98]",
                      mark === "indice" && "ring-1 ring-teal",
                      mark === "ecarte" && "opacity-55",
                    )}
                  >
                    <span className="text-[11px] tracking-wide text-fg-muted uppercase">
                      {seen ? "Inspecté" : "À ouvrir"}
                    </span>
                    <span className="mt-1 font-medium text-fg">{clue.title}</span>
                    <span className="text-xs text-fg-muted">{clue.caption}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        <aside className="rounded-xl bg-paper p-5 text-ink-fg shadow-[var(--shadow-paper)] sm:p-6">
          <p className="text-xs tracking-[0.18em] text-ink-muted uppercase">
            Carnet de tournée
          </p>
          <h2 className="mt-1 font-display text-2xl">Cadenas</h2>
          <p className="mt-2 text-sm leading-relaxed text-ink-muted">
            Vous avez marqué {markedClinical} élément
            {markedClinical > 1 ? "s" : ""} comme indice. Le code n’est pas
            ce que vous avez cliqué : c’est le nombre d’indices cliniquement
            justes.
          </p>
          <div
            className={cn(
              "mt-5 flex items-center justify-center gap-3",
              shake && "shake",
            )}
          >
            <button
              type="button"
              className="flex size-11 items-center justify-center rounded-md bg-paper-2 text-xl"
              onClick={() => setLockValue(Math.max(0, lockValue - 1))}
              aria-label="Diminuer"
            >
              −
            </button>
            <div className="flex size-20 flex-col items-center justify-center rounded-lg bg-ink text-fg">
              {unlocked ? (
                <Unlock className="size-6 text-teal" />
              ) : (
                <Lock className="size-6 text-warn" />
              )}
              <span className="font-display text-3xl tabular-nums">
                {lockValue}
              </span>
            </div>
            <button
              type="button"
              className="flex size-11 items-center justify-center rounded-md bg-paper-2 text-xl"
              onClick={() => setLockValue(Math.min(9, lockValue + 1))}
              aria-label="Augmenter"
            >
              +
            </button>
          </div>
          {unlocked ? (
            <div className="mt-5 space-y-3">
              <p className="text-sm text-teal-deep">
                Cinq regards. Plaie, teint, pilulier, chaussons, pièce froide.
                Le salon s’ouvre.
              </p>
              <Button variant="teal" className="w-full" onClick={() => go("constantes")}>
                Reconstituer le dossier
                <ArrowRight className="size-4" />
              </Button>
            </div>
          ) : (
            <div className="mt-5 space-y-3">
              <Button variant="paper" className="w-full" onClick={submitLock}>
                Tenter le code
              </Button>
              {tries >= 3 ? (
                <p className="text-sm text-ink-muted">
                  Indice : seuls les éléments qui changent la conduite de
                  soins comptent. Il y en a {TRUE_CLUE_COUNT}.
                </p>
              ) : tries >= 2 ? (
                <p className="text-sm text-ink-muted">
                  Moins que le nombre d’objets du salon. Plus que trois.
                </p>
              ) : tries >= 1 ? (
                <p className="text-sm text-rust">Ce n’est pas le bon nombre.</p>
              ) : null}
            </div>
          )}
        </aside>
      </div>

      {open ? (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-ink/70 p-4 sm:items-center"
          role="dialog"
          aria-modal="true"
          onClick={() => setOpen(null)}
        >
          <div
            className="max-h-[88dvh] w-full max-w-lg overflow-auto rounded-xl bg-paper p-4 text-ink-fg shadow-[var(--shadow-paper)] sm:p-6"
            onClick={(e) => e.stopPropagation()}
          >
            {open.image ? (
              <img
                src={open.image}
                alt=""
                className="mb-4 aspect-[4/3] w-full rounded-lg object-cover"
              />
            ) : (
              <div className="mb-4 flex aspect-[4/3] items-end rounded-lg bg-paper-2 p-4">
                <p className="font-display text-2xl">{open.title}</p>
              </div>
            )}
            <p className="text-xs tracking-wide text-ink-muted uppercase">
              {open.caption}
            </p>
            <h3 className="mt-1 font-display text-2xl">{open.title}</h3>
            <p className="mt-2 text-[15px] leading-relaxed text-ink-muted">
              {open.body}
            </p>
            {open.id === "piece" ? (
              <p className="mt-3 font-display text-3xl tabular-nums text-ink-fg">
                16 °C
              </p>
            ) : null}
            <div className="mt-5 grid grid-cols-2 gap-2">
              <Button
                variant="teal"
                onClick={() => {
                  markClue(open.id, "indice");
                  setOpen(null);
                }}
              >
                Indice clinique
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  markClue(open.id, "ecarte");
                  setOpen(null);
                }}
              >
                Décor
              </Button>
            </div>
            <button
              type="button"
              className="mt-3 flex w-full items-center justify-center gap-2 py-2 text-sm text-ink-muted"
              onClick={() => setOpen(null)}
            >
              <Eye className="size-4" />
              Fermer
            </button>
          </div>
        </div>
      ) : null}
    </main>
  );
}
