import { useEffect } from "react";
import { useGame } from "@/lib/game/store";
import { Hud } from "@/components/game/Hud";
import { Intro } from "@/components/game/screens/Intro";
import { Regard } from "@/components/game/screens/Regard";
import { Constantes } from "@/components/game/screens/Constantes";
import { Materiel } from "@/components/game/screens/Materiel";
import { Sbar } from "@/components/game/screens/Sbar";
import { Tca } from "@/components/game/screens/Tca";
import { Debrief } from "@/components/game/screens/Debrief";

export function GameApp() {
  const stage = useGame((s) => s.stage);
  const setHydrated = useGame((s) => s.setHydrated);

  useEffect(() => {
    const done = () => setHydrated();
    const result = useGame.persist.rehydrate();
    if (result && typeof result.then === "function") {
      void result.then(done, done);
    } else {
      done();
    }
  }, [setHydrated]);

  return (
    <div className="min-h-dvh bg-ink text-fg">
      {stage !== "intro" && stage !== "debrief" ? <Hud /> : null}
      {stage === "intro" ? <Intro /> : null}
      {stage === "regard" ? <Regard /> : null}
      {stage === "constantes" ? <Constantes /> : null}
      {stage === "materiel" ? <Materiel /> : null}
      {stage === "sbar" ? <Sbar /> : null}
      {stage === "tca" ? <Tca /> : null}
      {stage === "debrief" ? <Debrief /> : null}
    </div>
  );
}
