export const GAME_DURATION_MS = 30 * 60 * 1000;
export const SBAR_SECONDS = 60;

export const STAGES = [
  { id: "regard", label: "Regard", n: "01" },
  { id: "constantes", label: "Constantes", n: "02" },
  { id: "materiel", label: "Matériel", n: "03" },
  { id: "sbar", label: "Message", n: "04" },
  { id: "tca", label: "TCA", n: "05" },
] as const;

export type StageId =
  | "intro"
  | "regard"
  | "constantes"
  | "materiel"
  | "sbar"
  | "tca"
  | "debrief";

export type ClueId =
  | "plaie"
  | "teint"
  | "pilulier"
  | "chaussons"
  | "piece"
  | "cadre"
  | "the"
  | "tricot"
  | "telecommande";

export type Clue = {
  id: ClueId;
  title: string;
  caption: string;
  body: string;
  clinical: boolean;
  image?: string;
};

export const CLUES: Clue[] = [
  {
    id: "plaie",
    title: "La plaie",
    caption: "Pied gauche, berges",
    body: "Rougeur extensive, exsudat jaunâtre, berges macérées. L’aspect a changé depuis la dernière visite. Ce n’est plus un simple pansement de confort.",
    clinical: true,
    image: "/game/wound.jpg",
  },
  {
    id: "teint",
    title: "Le teint",
    caption: "Visage, muqueuses",
    body: "Joues congestives, lèvres sèches, regard vitreux. Mme Lambert est fébrile, pas seulement « fatiguée par l’hiver ».",
    clinical: true,
    image: "/game/face.jpg",
  },
  {
    id: "pilulier",
    title: "Le pilulier",
    caption: "Semainier du vendredi",
    body: "Les alvéoles du vendredi soir sont encore pleines. Doses non prises — y compris, peut-être, un antidiabétique ou un antibiotique déjà prescrit.",
    clinical: true,
    image: "/game/pillbox.jpg",
  },
  {
    id: "chaussons",
    title: "Les chaussons",
    caption: "Chaussage intérieur",
    body: "Chaussons fermés, trop étroits, marque de frottement. Microtraumatisme et macération : le terreau d’une plaie du pied chez une personne âgée.",
    clinical: true,
    image: "/game/slippers.jpg",
  },
  {
    id: "piece",
    title: "La pièce",
    caption: "Thermomètre mural",
    body: "Radiateur froid. Le thermomètre mural affiche 16 °C. Pièce trop froide : vasoconstriction, inconfort, mauvaise perfusion d’un pied déjà fragile.",
    clinical: true,
    image: "/game/thermometer.jpg",
  },
  {
    id: "cadre",
    title: "Le cadre",
    caption: "Buffet de l’entrée",
    body: "Une photo de famille un peu poussiéreuse. Elle raconte l’isolement, pas l’urgence de ce soir. À noter pour plus tard — ce n’est pas un indice clinique.",
    clinical: false,
  },
  {
    id: "the",
    title: "La tasse",
    caption: "Table basse",
    body: "Thé froid, à peine entamé. Hydratation incertaine, mais ce n’est pas ce qui fera basculer la décision ce soir.",
    clinical: false,
  },
  {
    id: "tricot",
    title: "Le tricot",
    caption: "Accoudoir",
    body: "Une pelote et des aiguilles. Signe qu’elle tenait encore debout il y a peu. Pas un élément de conduite de soins immédiat.",
    clinical: false,
  },
  {
    id: "telecommande",
    title: "La télécommande",
    caption: "Accoudoir du fauteuil",
    body: "Télévision allumée à bas volume. Elle n’est pas dans le coma. Rien à transmettre au spécialiste.",
    clinical: false,
  },
];

export const TRUE_CLUE_COUNT = CLUES.filter((c) => c.clinical).length;

export type VitalsSlot = "ta" | "spo2" | "glycemie" | "fc" | "temp";

export type Fiche = {
  id: string;
  slot: VitalsSlot;
  label: string;
  value: string;
  detail: string;
  inBag?: boolean;
};

export const FICHES: Fiche[] = [
  {
    id: "ta",
    slot: "ta",
    label: "Tension artérielle",
    value: "98 / 58 mmHg",
    detail: "Assise, bras droit",
  },
  {
    id: "spo2",
    slot: "spo2",
    label: "Saturation",
    value: "92 % AA",
    detail: "Oxymètre, 30 secondes",
  },
  {
    id: "glycemie",
    slot: "glycemie",
    label: "Glycémie capillaire",
    value: "2,48 g/L",
    detail: "Au pulpe, non à jeun",
  },
  {
    id: "fc",
    slot: "fc",
    label: "Fréquence cardiaque",
    value: "104 / min",
    detail: "Pouls radial, régulier",
  },
  {
    id: "temp",
    slot: "temp",
    label: "Température",
    value: "38,7 °C",
    detail: "Thermomètre tympanique — retrouvé dans la sacoche",
    inBag: true,
  },
];

export const VITAL_SLOTS: { id: VitalsSlot; title: string }[] = [
  { id: "ta", title: "Tension" },
  { id: "spo2", title: "SpO₂" },
  { id: "glycemie", title: "Glycémie" },
  { id: "fc", title: "Fréquence" },
  { id: "temp", title: "Température" },
];

export type KitStep = {
  id: string;
  title: string;
  hint: string;
};

export const KIT_STEPS: KitStep[] = [
  {
    id: "consent",
    title: "Identité et consentement",
    hint: "Vérifier Mme Lambert, expliquer la TCA, recueillir l’accord.",
  },
  {
    id: "install",
    title: "Installer la patiente",
    hint: "Fauteuil, pied dégagé, bon éclairage, intimité préservée.",
  },
  {
    id: "boot",
    title: "Allumer la tablette",
    hint: "Ouvrir la session TCA, vérifier le réseau.",
  },
  {
    id: "audio",
    title: "Tester audio et cadrage",
    hint: "Visage dans le champ, volume, micro, contre-jour.",
  },
  {
    id: "prep",
    title: "Préparer le champ d’examen",
    hint: "Gants, compresses, règle, champ propre autour de la plaie.",
  },
  {
    id: "camera",
    title: "Brancher la caméra d’examen",
    hint: "Pas la webcam d’ambiance : le spécialiste doit voir les berges.",
  },
];

export type DeviceId = "exam" | "webcam" | "stetho" | "gluco";

export const DEVICES: {
  id: DeviceId;
  title: string;
  detail: string;
  correct: boolean;
  image?: string;
}[] = [
  {
    id: "exam",
    title: "Caméra d’examen",
    detail: "Optique rapprochée, câble USB. Seule façon de montrer les berges.",
    correct: true,
    image: "/game/exam-camera.jpg",
  },
  {
    id: "webcam",
    title: "Webcam d’ambiance",
    detail: "Cadrage du salon. Le pied reste un détail flou.",
    correct: false,
    image: "/game/kit.jpg",
  },
  {
    id: "stetho",
    title: "Stéthoscope connecté",
    detail: "Utile pour un souffle. Inutile pour une plaie du pied.",
    correct: false,
  },
  {
    id: "gluco",
    title: "Glucomètre Bluetooth",
    detail: "La glycémie est déjà prise. Ce n’est pas le goulot d’étranglement.",
    correct: false,
  },
];

export type SbarKey = {
  id: string;
  label: string;
  test: (n: string) => boolean;
};

export const SBAR_KEYS: SbarKey[] = [
  {
    id: "identite",
    label: "Identité (Lambert, 84 ans)",
    test: (n) => /lambert/.test(n) || /\b84\b/.test(n),
  },
  {
    id: "isolement",
    label: "Isolement",
    test: (n) => /isol|seule|seul|entourage|famille abs/.test(n),
  },
  {
    id: "plaie",
    label: "Plaie du pied",
    test: (n) => /plaie|pied|ulcer|berges|exsud/.test(n),
  },
  {
    id: "fievre",
    label: "Fièvre",
    test: (n) => /fiev|febr|38/.test(n),
  },
  {
    id: "mt",
    label: "Médecin injoignable",
    test: (n) => /medecin|traitant|\bmt\b|injoign|joign/.test(n),
  },
  {
    id: "constantes",
    label: "Constantes chiffrées",
    test: (n) =>
      /tension|98|spo2|saturation|92|glycem|2[.,]48|38[.,]7|104/.test(n),
  },
  {
    id: "contexte",
    label: "Vendredi, fin de tournée",
    test: (n) => /vendredi|17h|tournee|week.?end|derniere visite/.test(n),
  },
  {
    id: "demande",
    label: "Demande claire (avis / domicile)",
    test: (n) =>
      /avis|tca|teleconsult|antibi|domicile|urgence|maintien|pansement/.test(n),
  },
];

export const SBAR_THRESHOLD = 6;

export type TcaActionId =
  | "situation"
  | "wound"
  | "vitals"
  | "home"
  | "shoes"
  | "pills";

export type TcaAction = {
  id: TcaActionId;
  label: string;
  nurseLine: string;
  doctorLine: (ctx: { examCamera: boolean; already: TcaActionId[] }) => string;
  feed: "room" | "wound" | "woundBlur" | "face" | "vitals" | "slippers" | "pills";
  points: (examCamera: boolean) => number;
};

export const TCA_ACTIONS: TcaAction[] = [
  {
    id: "situation",
    label: "Présenter la situation",
    nurseLine:
      "Mme Lambert, 84 ans, isolée. Dernière visite de la tournée. Plaie du pied modifiée, fébrile, médecin traitant injoignable. On cherche à éviter les urgences.",
    doctorLine: () =>
      "J’entends le contexte. Je n’ai encore rien vu. Montrez-moi ce qui justifie de rester à domicile.",
    feed: "face",
    points: () => 1,
  },
  {
    id: "wound",
    label: "Cadrer la plaie",
    nurseLine: "Je vous montre le pied gauche, berges et pourtour.",
    doctorLine: ({ examCamera }) =>
      examCamera
        ? "Là je vois. Rougeur extensive, exsudat, pas de nécrose franche, pas de crépitation. Merci d’avoir branché la caméra d’examen — sans elle je n’aurais pas tranché."
        : "C’est trop loin. Je vois un pansement, pas les berges. Si vous n’avez qu’une webcam d’ambiance, décrivez — mais je ne pourrai pas m’engager sur un maintien à domicile.",
    feed: "wound",
    points: (exam) => (exam ? 3 : 1),
  },
  {
    id: "vitals",
    label: "Lire les constantes",
    nurseLine:
      "Température 38,7 °C, TA 98/58, pouls 104, SpO₂ 92 % air ambiant, glycémie 2,48 g/L.",
    doctorLine: () =>
      "Fièvre, tachycardie, saturation limite, glycémie haute. Ça tient un traitement oral si l’examen local est propre et si vous pouvez repasser ce week-end.",
    feed: "vitals",
    points: () => 2,
  },
  {
    id: "home",
    label: "Décrire le domicile",
    nurseLine:
      "Elle vit seule. Pièce à 16 °C, radiateur éteint. Pas d’aidant ce soir. Je peux revenir demain.",
    doctorLine: () =>
      "L’isolement et le froid comptent autant que la plaie. Si vous n’êtes pas en mesure d’assurer une surveillance, je n’ai plus d’argument pour le domicile.",
    feed: "room",
    points: () => 1,
  },
  {
    id: "shoes",
    label: "Montrer le chaussage",
    nurseLine:
      "Chaussons fermés, trop étroits, marque de frottement. Elle marche encore un peu chez elle.",
    doctorLine: () =>
      "Facteur causal. Consigne claire : pied libre, pas de chausson fermé, décharge, contrôle de la glycémie.",
    feed: "slippers",
    points: () => 1,
  },
  {
    id: "pills",
    label: "Signaler le pilulier",
    nurseLine:
      "Les doses du vendredi soir sont encore dans le semainier. Observance douteuse.",
    doctorLine: () =>
      "Inutile de prescrire si rien n’est pris. Faites-lui prendre la première dose sous vos yeux, et prévoyez le passage de demain.",
    feed: "pills",
    points: () => 1,
  },
];

export const TCA_DOMICILE_SCORE = 7;

export const DEBRIEF_POINTS = [
  {
    title: "Le spécialiste ne voit que ce que vous lui montrez",
    body: "Sans cadrage de plaie, sans constantes, sans contexte, l’avis se résume à « allez aux urgences ». La TCA n’est pas une magie à distance : c’est un examen clinique porté par l’IDEL.",
  },
  {
    title: "Cinq regards valent un dossier",
    body: "Plaie, teint, pilulier, chaussons, température de la pièce. Ce sont des données, pas du décor. Elles tiennent dans une transmission de soixante secondes.",
  },
  {
    title: "Le bon câble change la décision",
    body: "La webcam d’ambiance rassure le médecin sur la pièce. La caméra d’examen lui permet de traiter. Brancher le bon dispositif n’est pas un détail technique.",
  },
  {
    title: "SBAR n’est pas de la paperasse",
    body: "Situation, contexte, constantes, demande. Un message flou produit une décision floue. Un message complet permet le maintien à domicile.",
  },
  {
    title: "Pas de gagnant sans examen",
    body: "Le jeu n’a pas de vainqueur individuel. L’équipe gagne si l’examen est fait. C’est exactement le contrat d’une TCA réelle.",
  },
];
