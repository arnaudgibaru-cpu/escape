import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  CLUES,
  DEVICES,
  FICHES,
  GAME_DURATION_MS,
  KIT_STEPS,
  TCA_ACTIONS,
  TCA_DOMICILE_SCORE,
  type ClueId,
  type DeviceId,
  type StageId,
  type TcaActionId,
  type VitalsSlot,
} from "@/lib/game/content";
import { scoreSbar } from "@/lib/game/sbar";

export type Mark = "indice" | "ecarte" | null;

export type ChatLine = {
  who: "nurse" | "doctor" | "system";
  text: string;
};

type GameState = {
  hydrated: boolean;
  stage: StageId;
  teamName: string;
  startedAt: number | null;
  pauseStartedAt: number | null;
  pausedMs: number;
  regard: {
    inspected: ClueId[];
    marks: Partial<Record<ClueId, Mark>>;
    lockValue: number;
    tries: number;
    unlocked: boolean;
  };
  constantes: {
    placed: Partial<Record<VitalsSlot, string>>;
    bagOpen: boolean;
    foundTemp: boolean;
    selectedFiche: string | null;
    unlocked: boolean;
  };
  materiel: {
    order: string[];
    plugged: DeviceId | null;
    orderOk: boolean;
    unlocked: boolean;
  };
  sbar: {
    situation: string;
    background: string;
    assessment: string;
    recommendation: string;
    running: boolean;
    endsAt: number | null;
    tries: number;
    lastScore: number;
    unlocked: boolean;
  };
  tca: {
    done: TcaActionId[];
    chat: ChatLine[];
    decided: boolean;
    score: number;
    domicile: boolean | null;
  };
  setHydrated: () => void;
  setTeamName: (name: string) => void;
  start: () => void;
  togglePause: () => void;
  remainingMs: () => number;
  go: (stage: StageId) => void;
  inspectClue: (id: ClueId) => void;
  markClue: (id: ClueId, mark: Mark) => void;
  setLockValue: (n: number) => void;
  tryLock: () => "ok" | "fail";
  selectFiche: (id: string | null) => void;
  placeFiche: (slot: VitalsSlot) => void;
  toggleBag: (open?: boolean) => void;
  takeTemp: () => void;
  moveStep: (index: number, dir: -1 | 1) => void;
  plugDevice: (id: DeviceId) => void;
  setSbarField: (
    field: "situation" | "background" | "assessment" | "recommendation",
    value: string,
  ) => void;
  startSbarTimer: () => void;
  submitSbar: () => { passed: boolean; score: number };
  doTcaAction: (id: TcaActionId) => void;
  decideTca: () => void;
  reset: () => void;
};

const initialRegard = {
  inspected: [] as ClueId[],
  marks: {} as Partial<Record<ClueId, Mark>>,
  lockValue: 0,
  tries: 0,
  unlocked: false,
};

const initialConstantes = {
  placed: {} as Partial<Record<VitalsSlot, string>>,
  bagOpen: false,
  foundTemp: false,
  selectedFiche: null as string | null,
  unlocked: false,
};

function shuffleIds(seed: number) {
  const ids = KIT_STEPS.map((s) => s.id);
  let s = Math.abs(seed) + 1;
  for (let i = ids.length - 1; i > 0; i--) {
    s = (s * 16807) % 2147483647;
    const j = s % (i + 1);
    const a = ids[i];
    const b = ids[j];
    if (a && b) {
      ids[i] = b;
      ids[j] = a;
    }
  }
  if (ids.join() === KIT_STEPS.map((step) => step.id).join()) {
    const last = ids.pop();
    if (last) ids.unshift(last);
  }
  return ids;
}

const initialMateriel = {
  order: shuffleIds(17),
  plugged: null as DeviceId | null,
  orderOk: false,
  unlocked: false,
};

const initialSbar = {
  situation: "",
  background: "",
  assessment: "",
  recommendation: "",
  running: false,
  endsAt: null as number | null,
  tries: 0,
  lastScore: 0,
  unlocked: false,
};

const initialTca = {
  done: [] as TcaActionId[],
  chat: [
    {
      who: "doctor" as const,
      text: "Docteur Morel, infectiologie. Je n’ai pour l’instant que ce que votre caméra me montre. Allez-y — je ne peux rien sans vous.",
    },
  ] as ChatLine[],
  decided: false,
  score: 0,
  domicile: null as boolean | null,
};

function checkConstantes(placed: Partial<Record<VitalsSlot, string>>) {
  return FICHES.every((f) => placed[f.slot] === f.id);
}

function checkOrder(order: string[]) {
  return order.join() === KIT_STEPS.map((s) => s.id).join();
}

export const useGame = create<GameState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      stage: "intro",
      teamName: "",
      startedAt: null,
      pauseStartedAt: null,
      pausedMs: 0,
      regard: initialRegard,
      constantes: initialConstantes,
      materiel: initialMateriel,
      sbar: initialSbar,
      tca: initialTca,
      setHydrated: () => set({ hydrated: true }),
      setTeamName: (teamName) => set({ teamName }),
      start: () => {
        const now = Date.now();
        set({
          stage: "regard",
          startedAt: now,
          pauseStartedAt: null,
          pausedMs: 0,
          regard: { ...initialRegard },
          constantes: { ...initialConstantes, placed: {} },
          materiel: { ...initialMateriel, order: shuffleIds(now), plugged: null },
          sbar: { ...initialSbar },
          tca: {
            ...initialTca,
            done: [],
            chat: [...initialTca.chat],
          },
        });
      },
      togglePause: () => {
        const { pauseStartedAt, pausedMs } = get();
        if (pauseStartedAt) {
          set({
            pauseStartedAt: null,
            pausedMs: pausedMs + (Date.now() - pauseStartedAt),
          });
        } else {
          set({ pauseStartedAt: Date.now() });
        }
      },
      remainingMs: () => {
        const { startedAt, pauseStartedAt, pausedMs } = get();
        if (!startedAt) return GAME_DURATION_MS;
        const frozen = pauseStartedAt ? Date.now() - pauseStartedAt : 0;
        return Math.max(
          0,
          GAME_DURATION_MS - (Date.now() - startedAt - pausedMs - frozen),
        );
      },
      go: (stage) => set({ stage }),
      inspectClue: (id) =>
        set((s) => ({
          regard: {
            ...s.regard,
            inspected: s.regard.inspected.includes(id)
              ? s.regard.inspected
              : [...s.regard.inspected, id],
          },
        })),
      markClue: (id, mark) =>
        set((s) => ({
          regard: {
            ...s.regard,
            marks: { ...s.regard.marks, [id]: mark },
          },
        })),
      setLockValue: (n) =>
        set((s) => ({ regard: { ...s.regard, lockValue: n } })),
      tryLock: () => {
        const { regard } = get();
        const ok = regard.lockValue === CLUES.filter((c) => c.clinical).length;
        set({
          regard: {
            ...regard,
            tries: regard.tries + 1,
            unlocked: ok || regard.unlocked,
          },
        });
        return ok ? "ok" : "fail";
      },
      selectFiche: (id) =>
        set((s) => ({
          constantes: { ...s.constantes, selectedFiche: id },
        })),
      placeFiche: (slot) => {
        const { constantes } = get();
        if (!constantes.selectedFiche) {
          const current = constantes.placed[slot];
          if (!current) return;
          const placed = { ...constantes.placed };
          delete placed[slot];
          set({
            constantes: {
              ...constantes,
              placed,
              selectedFiche: current,
              unlocked: false,
            },
          });
          return;
        }
        const placed = {
          ...constantes.placed,
          [slot]: constantes.selectedFiche,
        };
        set({
          constantes: {
            ...constantes,
            placed,
            selectedFiche: null,
            unlocked: checkConstantes(placed),
          },
        });
      },
      toggleBag: (open) =>
        set((s) => ({
          constantes: {
            ...s.constantes,
            bagOpen: open ?? !s.constantes.bagOpen,
          },
        })),
      takeTemp: () =>
        set((s) => ({
          constantes: {
            ...s.constantes,
            foundTemp: true,
            selectedFiche: "temp",
            bagOpen: false,
          },
        })),
      moveStep: (index, dir) => {
        const { materiel } = get();
        const next = [...materiel.order];
        const j = index + dir;
        if (j < 0 || j >= next.length) return;
        const a = next[index];
        const b = next[j];
        if (!a || !b) return;
        next[index] = b;
        next[j] = a;
        const orderOk = checkOrder(next);
        set({
          materiel: {
            ...materiel,
            order: next,
            orderOk,
            unlocked: orderOk && materiel.plugged === "exam",
          },
        });
      },
      plugDevice: (id) => {
        const { materiel } = get();
        const orderOk = checkOrder(materiel.order);
        const correct = DEVICES.find((d) => d.id === id)?.correct ?? false;
        set({
          materiel: {
            ...materiel,
            plugged: id,
            orderOk,
            unlocked: orderOk && correct,
          },
        });
      },
      setSbarField: (field, value) =>
        set((s) => ({ sbar: { ...s.sbar, [field]: value } })),
      startSbarTimer: () =>
        set((s) => ({
          sbar: {
            ...s.sbar,
            running: true,
            endsAt: Date.now() + 60_000,
          },
        })),
      submitSbar: () => {
        const { sbar } = get();
        const text = [
          sbar.situation,
          sbar.background,
          sbar.assessment,
          sbar.recommendation,
        ].join("\n");
        const result = scoreSbar(text);
        set({
          sbar: {
            ...sbar,
            running: false,
            endsAt: null,
            tries: sbar.tries + 1,
            lastScore: result.score,
            unlocked: result.passed || sbar.unlocked,
          },
        });
        return { passed: result.passed, score: result.score };
      },
      doTcaAction: (id) => {
        const { tca, materiel } = get();
        if (tca.done.includes(id) || tca.decided) return;
        const action = TCA_ACTIONS.find((a) => a.id === id);
        if (!action) return;
        const examCamera = materiel.plugged === "exam";
        set({
          tca: {
            ...tca,
            done: [...tca.done, id],
            score: tca.score + action.points(examCamera),
            chat: [
              ...tca.chat,
              { who: "nurse", text: action.nurseLine },
              {
                who: "doctor",
                text: action.doctorLine({ examCamera, already: tca.done }),
              },
            ],
          },
        });
      },
      decideTca: () => {
        const { tca, materiel } = get();
        if (tca.decided) return;
        const examCamera = materiel.plugged === "exam";
        const domicile =
          tca.score >= TCA_DOMICILE_SCORE &&
          examCamera &&
          tca.done.includes("wound") &&
          tca.done.includes("vitals");
        const text = domicile
          ? "Je m’engage : antibiothérapie orale, pansement hydrocellulaire, décharge du pied, première dose maintenant, vous repassez demain. Maintien à domicile. Sans l’examen que vous venez de faire, j’aurais envoyé Mme Lambert aux urgences."
          : "Je ne peux pas m’engager sur un maintien à domicile : l’examen est trop incomplet. Orientez vers les urgences. Le spécialiste ne peut rien sans ce que l’IDEL lui montre et lui dit.";
        set({
          tca: {
            ...tca,
            decided: true,
            domicile,
            chat: [
              ...tca.chat,
              { who: "system", text: "Décision du médecin à distance" },
              { who: "doctor", text },
            ],
          },
        });
      },
      reset: () =>
        set({
          stage: "intro",
          teamName: "",
          startedAt: null,
          pauseStartedAt: null,
          pausedMs: 0,
          regard: { ...initialRegard },
          constantes: { ...initialConstantes, placed: {} },
          materiel: { ...initialMateriel, order: shuffleIds(Date.now()), plugged: null },
          sbar: { ...initialSbar },
          tca: { ...initialTca, done: [], chat: [...initialTca.chat] },
        }),
    }),
    {
      name: "derniere-visite-v1",
      skipHydration: true,
      partialize: (s) => ({
        stage: s.stage,
        teamName: s.teamName,
        startedAt: s.startedAt,
        pauseStartedAt: s.pauseStartedAt,
        pausedMs: s.pausedMs,
        regard: s.regard,
        constantes: s.constantes,
        materiel: s.materiel,
        sbar: s.sbar,
        tca: s.tca,
      }),
    },
  ),
);
