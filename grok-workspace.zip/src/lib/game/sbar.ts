import { normalizeFr } from "@/lib/utils";
import { SBAR_KEYS, SBAR_THRESHOLD } from "@/lib/game/content";

export function scoreSbar(text: string) {
  const n = normalizeFr(text);
  const hits = SBAR_KEYS.filter((k) => k.test(n)).map((k) => k.id);
  return {
    hits,
    missing: SBAR_KEYS.filter((k) => !hits.includes(k.id)),
    score: hits.length,
    passed: hits.length >= SBAR_THRESHOLD,
  };
}
